# HELPER
# KHIE WAS HERE
# </> NOOB CODER 2K17
import KIA
from KIA import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from KhieBots.thrift.protocol import TCompactProtocol
from KhieBots.thrift.transport import THttpClient
from KhieBots.ttypes import LoginRequest
from Naked.toolshed.shell import execute_js
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
from threading import Thread, activeCount
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
noobcoder = LINE("ksamr077@gmail.com","ssaa1122")
noobcoder.log("Auth Token : " + str(noobcoder.authToken))
noobcoder.log("Timeline Token : " + str(noobcoder.tl.channelAccessToken))

ki = LineClient("ksamryyyy@gmail.com","ssaa1122")
ki.log("Auth Token : " + str(ki.authToken))
channel1 = LineChannel(ki)
ki.log("Channel Access Token : " + str(channel1.channelAccessToken))
lineProfile = ki.getProfile()
lineSettings = ki.getSettings()
Amid = ki.getProfile().mid
responsename2 = ki.getProfile().displayName

kk = LineClient("ksamr011@gmail.com","ssaa1122")
kk.log("Auth Token : " + str(kk.authToken))
channel2 = LineChannel(kk)
kk.log("Channel Access Token : " + str(channel2.channelAccessToken))
lineProfile = kk.getProfile()
lineSettings = kk.getSettings()
Bmid = ki.getProfile().mid
responsename3 = ki.getProfile().displayName

kc = LineClient("ericbots59@gmail.com","ssaa1122")
kc.log("Auth Token : " + str(kc.authToken))
channel3 = LineChannel(kc)
kc.log("Channel Access Token : " + str(channel3.channelAccessToken))
lineProfile = kc.getProfile()
lineSettings = kc.getSettings()
Cmid = kc.getProfile().mid
responsename4 = kc.getProfile().displayName

km = LineClient("ericbots511@gmail.com","ssaa1122")
km.log("Auth Token : " + str(km.authToken))
channel4 = LineChannel(km)
km.log("Channel Access Token : " + str(channel4.channelAccessToken))
lineProfile = km.getProfile()
lineSettings = km.getSettings()
Dmid = km.getProfile().mid
responsename5 = km.getProfile().displayName

kb = LineClient("ericbots513@gmail.com","ssaa1122")
kb.log("Auth Token : " + str(kb.authToken))
channel5 = LineChannel(kb)
kb.log("Channel Access Token : " + str(channel5.channelAccessToken))
lineProfile = kb.getProfile()
lineSettings = kb.getSettings()
Emid = kb.getProfile().mid
responsename6 = kb.getProfile().displayName

kn = LineClient("ericbots514@gmail.com","ssaa1122")
kn.log("Auth Token : " + str(kn.authToken))
channel6 = LineChannel(kn)
kn.log("Channel Access Token : " + str(channel6.channelAccessToken))
lineProfile = kn.getProfile()
lineSettings = kn.getSettings()
Fmid = kb.getProfile().mid
responsename7 = kn.getProfile().displayName

ko = LineClient("eriic770@gmail.com","ssaa1122")
ko.log("Auth Token : " + str(ko.authToken))
channel7 = LineChannel(ko)
ko.log("Channel Access Token : " + str(channel7.channelAccessToken))
lineProfile = ko.getProfile()
lineSettings = ko.getSettings()
Gmid = ko.getProfile().mid
responsename8 = kb.getProfile().displayName

kw = LineClient("eriic7700@gmail.com","ssaa1122")
kw.log("Auth Token : " + str(kw.authToken))
channel8 = LineChannel(kw)
kw.log("Channel Access Token : " + str(channel8.channelAccessToken))
lineProfile = kw.getProfile()
lineSettings = kw.getSettings()
Hmid = kw.getProfile().mid
responsename9 = kw.getProfile().displayName

ke = LineClient("eriic8880@gmail.com","ssaa1122")
ke.log("Auth Token : " + str(ke.authToken))
channel9 = LineChannel(ke)
ke.log("Channel Access Token : " + str(channel9.channelAccessToken))
lineProfile = ke.getProfile()
lineSettings = ke.getSettings()
Imid = ke.getProfile().mid
responsename10 = ke.getProfile().displayName

ky = LineClient("ericbots200@gmail.com","ssaa1122")
ky.log("Auth Token : " + str(ky.authToken))
channel10 = LineChannel(ky)
ky.log("Channel Access Token : " + str(channel10.channelAccessToken))
lineProfile = ky.getProfile()
lineSettings = ky.getSettings()
Jmid = ky.getProfile().mid
responsename11 = ky.getProfile().displayName

sw = LineClient("ksamr880@gmail.com","ssaa1122")
sw.log("Auth Token : " + str(sw.authToken))
channel11 = LineChannel(sw)
sw.log("Channel Access Token : " + str(channel11.channelAccessToken))
lineProfile = sw.getProfile()
lineSettings = sw.getSettings()
Zmid = sw.getProfile().mid
responsename12 = sw.getProfile().displayName

#sx = LineClient("ksamryyyy@gmail.com","ssaa1122")
#sx.log("Auth Token : " + str(sx.authToken))
#channel12 = LineChannel(sx)
#sx.log("Channel Access Token : " + str(channel12.channelAccessToken))
#lineProfile = sx.getProfile()
#lineSettings = sx.getSettings()
#Xmid = sx.getProfile().mid
#responsename13 = sx.getProfile().displayName

js = LineClient("ksamr088@gmail.com","ssaa1122")
js.log("Auth Token : " + str(js.authToken))
channel13 = LineChannel(js)
js.log("Channel Access Token : " + str(channel13.channelAccessToken))
lineProfile = js.getProfile()
lineSettings = js.getSettings()
JSmid = js.getProfile().mid
responsename14 = js.getProfile().displayName

print("---LOGIN SUCCES---")

poll = LinePoll(noobcoder)
call = noobcoder
creator = ["u9d03d5098465a5f8683e71d20e350022"]
owner = ["u9d03d5098465a5f8683e71d20e350022"]
admin = ["u9d03d5098465a5f8683e71d20e350022"]
staff = ["u9d03d5098465a5f8683e71d20e350022"]
mid = noobcoder.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = km.getProfile().mid
Emid = kb.getProfile().mid
Fmid = kn.getProfile().mid
Gmid = ko.getProfile().mid
Hmid = kw.getProfile().mid
Imid = ke.getProfile().mid
Jmid = ky.getProfile().mid
Zmid = sw.getProfile().mid
#Xmid = sx.getProfile().mid
JSmid = js.getProfile().mid
KAC = [noobcoder,ki,kk,kc,km,kb,kn,ko,kw,ke,ky]
ABC = [ki,kk,kc,km,kb,kn,ko,kw,ke,ky]
Bots = [mid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid,Zmid,JSmid]
Dpk = admin + staff

protectqr = []
protectkick = []
protectjoin = []
protectinvite = []
protectcancel = []
protectantijs = []
ghost = []
welcome = []

responsename1 = ki.getProfile().displayName
responsename2 = kk.getProfile().displayName
responsename3 = kc.getProfile().displayName
responsename4 = km.getProfile().displayName
responsename5 = kb.getProfile().displayName
responsename6 = kn.getProfile().displayName
responsename7 = ko.getProfile().displayName
responsename8 = kw.getProfile().displayName
responsename9 = ke.getProfile().displayName
responsename10 = ky.getProfile().displayName

settings = {
    "Picture":False,
    "group":{},
    "groupPicture":False,
    "changePicture":False,
    "autoJoinTicket":True,
    "userAgent": [
        "Mozilla/5.0 (X11; U; Linux i586; de; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; U; Linux amd64; rv:5.0) Gecko/20100101 Firefox/5.0 (Debian)",
        "Mozilla/5.0 (X11; U; Linux amd64; en-US; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 FirePHP/0.5",
        "Mozilla/5.0 (X11; Linux x86_64; rv:5.0) Gecko/20100101 Firefox/5.0 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux x86_64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; Linux ppc; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (X11; Linux AMD64) Gecko Firefox/5.0",
        "Mozilla/5.0 (X11; FreeBSD amd64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20110619 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1; rv:6.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 6.1.1; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.2; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; U; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.1; rv:2.0.1) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; WOW64; rv:5.0) Gecko/20100101 Firefox/5.0",
        "Mozilla/5.0 (Windows NT 5.0; rv:5.0) Gecko/20100101 Firefox/5.0"
    ]
}

wait = {
    "limit": 5,
    "owner":{},
    "admin":{},
    "addadmin":False,
    "delladmin":False,
    "staff":{},
    "addstaff":False,
    "dellstaff":False,
    "bots":{},
    "addbots":False,
    "dellbots":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "Talkblacklist":{},
    "Talkwblacklist":False,
    "Talkdblacklist":False,
    "talkban":True,
    "contact":False,
    'autoJoin':True,
    'InCiak': False,
    'autoAdd':True,
    'autoRead':False,
    'autoLeave':False,
    'autoLeave1':False,
    "detectMention":True,
    "Mentionkick":False,
    "welcomeOn":False,
    "sticker":False,
    "selfbot":True,
    "protectantijsOn":True,
    "ghostOn":True,
    "mention":"",
    "Respontag":"",
    "welcome":"",
    "comment":"Like like & like ",
    "message":"thank you for adding me (Eric bots)",
    }

read = {
    "readPoint":{},
    "readMember":{},
    "readTime":{},
    "ROM":{},
}

cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
with open('creator.json', 'r') as fp:
    creator = json.load(fp)
with open('owner.json', 'r') as fp:
    owner = json.load(fp)

Setbot = codecs.open("setting.json","r","utf-8")
Setmain = json.load(Setbot)

mulai = time.time()

tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
#=======================================================
waitOpen = codecs.open("noobcoder/wait.json","r","utf-8")
settingsOpen = codecs.open("noobcoder/temp.json","r","utf-8")
premiumOpen = codecs.open("noobcoder/user.json","r","utf-8")
javaOpen = codecs.open("noobcoder/java.json","r","utf-8")
#=====================================================================
#=====================================================================
noobcoderProfile = noobcoder.getProfile()
noobcoderSettings = noobcoder.getSettings()
noobcoderPoll = OEPoll(noobcoder)
noobcoderMID = noobcoder.getProfile().mid
#=====================================================================
loop = asyncio.get_event_loop()
myAdmin = [""]
botStart = time.time()
msg_dict = {}
temp_flood = {}
steals = []
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
premium = json.load(premiumOpen)
java = json.load(javaOpen)

hoho = {
    "savefile": False,
    "namefile": "",
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

read = { 
    "readMember": {},
    "readPoint": {}
}

wmin = {
    "wMessage": False,
    "textnya": "Enjoying in this group",
}

lvin = {
    "lMessage": False,
    "textnya": "See u next time",
}

tailah = {
    "siderTemp": {},
    "siderPesan": "You can join chat?",
}

setbot = {
    "background": "#000000",
    "text": "#ffffff",
    "separator": "#ffffff"
}

gwcool = {
    "squad": "Eric Bots",
}

javascript = {
    "jskick": "bypass",
    "jskick1": "cleanse",
    "cancels": "cancel",
}
#=====================================================================
#=====================================================================
settings["myProfile"]["displayName"] = noobcoderProfile.displayName
settings["myProfile"]["statusMessage"] = noobcoderProfile.statusMessage
settings["myProfile"]["pictureStatus"] = noobcoderProfile.pictureStatus
cont = noobcoder.getContact(noobcoderMID)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = noobcoder.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
#=====================================================================
#=====================================================================
with open("noobcoder/temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("noobcoder/wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu
def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)

def restartBot():
    python = sys.executable
    os.execl(python, python, *sys.argv)

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)

def mentionMembers(to, mid):
    try:
        arrData = ""
        textx = "DAFTAR JONES「{}」\n\n  [ Silahkan pilih ]\n1. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(noobcoder.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        noobcoder.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        noobcoder.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "Hallo ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["mention"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(noobcoder.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        noobcoder.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        noobcoder.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "Hallo  ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = noobcoder.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+wait["welcome"]+"\nNama grup : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(noobcoder.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        noobcoder.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        noobcoder.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def sendMention(to, mid, firstmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x \n"
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        today = datetime.today()
        future = datetime(2018,3,1)
        hari = (str(future - today))
        comma = hari.find(",")
        hari = hari[:comma]
        teman = noobcoder.getAllContactIds()
        gid = noobcoder.getGroupIdsJoined()
        tz = pytz.timezone("Asia/Jakarta")
        timeNow = datetime.now(tz=tz)
        eltime = time.time() - mulai
        bot = runtime(eltime)
        text += mention+"◐ Jam : "+datetime.strftime(timeNow,'%H:%M:%S')+" Wib\n⏩ Group : "+str(len(gid))+"\n⏩ Teman : "+str(len(teman))+"\n⏩ Expired : In "+hari+"\n⏩ Version : ANTIJS2\n⏩ Tanggal : "+datetime.strftime(timeNow,'%Y-%m-%d')+"\n⏩ Runtime : \n • "+bot
        noobcoder.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        noobcoder.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def command(text):
    pesan = text.lower()
    if pesan.startswith(Setmain["keyCommand"]):
        cmd = pesan.replace(Setmain["keyCommand"],"")
    else:
        cmd = "command"
    return cmd
def inSteals(from_):
    global steals
    if from_ in steals:
        return True
    return False
def appendSteals(from_):
    try:
        global steals
        if from_ in steals:
            return
        return steals.append(from_)
    except:
        return False
def clearSteals():
    global steals
    steals = []
    return
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "Eric Bots",
            "iconUrl": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u708242457e625a5ef306804d8c0b0ac5').pictureStatus),
            "linkUrl": "line://nv/profilePopup/mid=u708242457e625a5ef306804d8c0b0ac5"
        }
    }
    sendTemplate(to, data)
def sendTemplate(to, data):
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = client.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(group, data):
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def helppss(to):
    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Eric Bots",
                    "size": "xl",
                    "color": "#ffffff",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Chatbot",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=chatbot"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Feature",
                            "align": "center",
                            "size": "sm",
                            "color": "#ffffff",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=feature"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Images",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=images"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Profile",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=profile"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Protect",
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=protect"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Social",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=social"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Timeline",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=timeline"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Translate",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=translate"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Settings",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=settings"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": "#ffffff",
            "borderWidth": "2px"
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }
  }},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Eric Bots",
                    "size": "xl",
                    "color": "#ffffff",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Banning",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=banning"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Wordban",
                            "align": "center",
                            "size": "sm",
                            "color": "#ffffff",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=wordban"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Friend",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=friend"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Self",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=self"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Memegen",
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=memegen"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Kick",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=kick"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Utility",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=utility"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Github",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=github"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "About",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=about"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": "#ffffff",
            "borderWidth": "2px"
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }
  }},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "Eric Bots",
                    "size": "xl",
                    "color": "#ffffff",
                    "weight": "bold"
                  }
                ],
                "margin": "lg"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "image",
                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg"
                  }
                ],
                "cornerRadius": "100px",
                "borderColor": "#ffffff",
                "borderWidth": "2px",
                "width": "40px",
                "height": "40px"
              }
            ]
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ]
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Group",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=group"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Mention",
                            "align": "center",
                            "size": "sm",
                            "color": "#ffffff",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=mention"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Steal",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=steal"
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "List",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=list"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Bcast",
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xs",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=bcast"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Leave",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text="
                            }
                          }
                        ]
                      }
                    ]
                  },
                  {
                    "type": "separator"
                  },
                  {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Reboot",
                        "size": "sm",
                        "color": "#ffffff",
                        "align": "center",
                        "action": {
                          "type": "uri",
                          "label": "action",
                          "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=reboot"
                        }
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Timeleft",
                            "size": "sm",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=timeleft"
                            }
                          }
                        ]
                      },
                      {
                        "type": "separator"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Logout",
                            "size": "xs",
                            "color": "#ffffff",
                            "align": "center",
                            "action": {
                              "type": "uri",
                              "label": "action",
                              "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=logout"
                            }
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ],
            "borderColor": "#ffffff",
            "borderWidth": "2px"
          }
        ]
      }
    ],
    "cornerRadius": "xl",
    "borderColor": "#ffffff",
    "borderWidth": "4px"
  },
  "styles": {
    "body": {
      "backgroundColor": "#000000"
    }}}]}}
    sendTemplate(to,data)
def foro(to, text):
    data = {
    "type": "flex",
    "altText": text,
    "contents": {
    "type": "bubble",
    "styles": {
    "footer": {
    "backgroundColor": "{}".format(setbot["background"])
    }
    },
    "footer": {
    "type": "box",
    "layout": "vertical",
     "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "{}".format(setbot["separator"]),
    "spacing": "sm",
    "contents": [
    {
    "type": "box",
    "layout": "baseline",
    "contents": [
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    },
    {
    "type": "text",
    "text": text,
    "color": "{}".format(setbot["text"]),
    "gravity": "center",
    "align":"center",
    "wrap": True,
    "size": "md"
    },
    {
    "type": "icon",
    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
    "size": "md"
    },
    ]
    }
    ]
    }
    }
    }
    sendTemplate(to, data)
def helpss(to):
    ret_ = helpers(to)
    k = len(ret_)//10
    for aa in range(k+1):
        data = {
            "type": "flex",
            "altText": "Help",
            "contents": {
                "type": "carousel",
                "contents": ret_[aa*10 : (aa+1)*10]
            }
        }
        sendTemplate(to, data)
def helpers(to):
    ret_ = []
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Login%20sb"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Restart%20sb"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Logout%20sb"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Login sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Restart sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Logout sb',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     }
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
      }
    }
    )
    ret_.append(
        {
            "styles": {"body": {"backgroundColor": "{}".format(setbot["background"])},"header": {"backgroundColor": "{}".format(setbot["background"])}},
            "type": "bubble",
            "body": {"contents": [{
                "type": "box",
                "layout": "baseline",
                "contents": [
                    {
                        "type": "spacer",
                        "size": "xxl"
                    },
                    {
                        "contents": [{
                        "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                        "size": "xxs",
                        "type": "image",
                        "action": {
                        "type": "uri",
                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Reader"
                    }
                }, {
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                    "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Support"
                                                    }
                                                },{
                                                    "url": "https://i.ibb.co/jrrMPdG/1553179449707.jpg",
                                                    "size": "xxs",
                                                   "type": "image",
                                                    "action": {
                                                        "type": "uri",
                                                        "uri": "line://app/1643727178-0XPGAaRX?type=fotext&text=Mentions"
                                                    }
                                                }],
                                                "layout": "horizontal",
                                                "type": "box",
                                                "flex": 1
                                            }, 
                                                                 {
        "type": "box",
        "layout": "horizontal",
        "spacing": "xxl",       
        "contents": [
          {
            "type": "text", 
            "text": 'Reader',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center",
          },
          {
            "type": "text",
            "text": 'Support',
            "color": "{}".format(setbot["text"]),
            "size": "xs",
            "align": "center"
          },
          {
            "type": "text", 
            "text": 'Mentions',
            "color": "{}".format(setbot["text"]),
            "size": "xs"
          }
        ]
      },
            ],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          },
          {
            "contents": [
              {
       "type": "spacer",
       "size": "xl"
     }
],
            "type": "box",
            "spacing": "xs",
            "layout": "vertical"
          }  
        ],
        "type": "box",
        "spacing": "xs",
        "layout": "vertical",
      }
    }
    )
    return ret_
def support(to):
    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "carousel",
  "contents": [
    {
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "khiewuzzheree",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u2cf74acf6ed04d122def4db8ffdd2e39').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('u2cf74acf6ed04d122def4db8ffdd2e39').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~khiewuzzheree"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }
},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "welovebigbang",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('u6d7732713d9157756ed84fd4bc3191e4').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('u6d7732713d9157756ed84fd4bc3191e4').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~welovebigbang"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }
},{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer"
          },
          {
            "type": "box",
            "layout": "baseline",
            "contents": [
              {
                "type": "icon",
                "url": "https://i.ibb.co/zHkYgV7/left.png",
                "offsetStart": "10px"
              },
              {
                "type": "text",
                "color": "#Ffffff",
                "text": "Friend search",
                "size": "md",
                "offsetStart": "20px"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "lg"
              }
            ]
          }
        ],
        "backgroundColor": "#464F69"
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "spacer",
            "size": "xxl"
          },
          {
            "type": "box",
            "layout": "horizontal",
            "contents": [
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "offsetStart": "10px",
                "cornerRadius": "xl",
                "borderColor": "#adb5bd",
                "borderWidth": "6px",
                "width": "20px",
                "height": "20px"
              },
              {
                "type": "text",
                "text": "ID",
                "offsetStart": "18px"
              },
              {
                "type": "box",
                "layout": "vertical",
                "contents": [
                  {
                    "type": "text",
                    "text": "."
                  }
                ],
                "width": "20px",
                "height": "20px",
                "cornerRadius": "xl",
                "borderWidth": "6px",
                "backgroundColor": "#adb5bd",
                "offsetEnd": "85px"
              },
              {
                "type": "text",
                "text": "Phone number",
                "offsetEnd": "75px"
              }
            ]
          },
          {
            "type": "spacer"
          }
        ]
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "gkada.line",
                "offsetStart": "10px",
                "size": "sm"
              }
            ],
            "borderColor": "#adb5bd",
            "borderWidth": "1px",
            "offsetStart": "10px"
          },
          {
            "type": "spacer",
            "size": "xxl"
          }
        ]
      },
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
            "type": "filler"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(noobcoder.getContact('ucad303333969352466bfecd62089a1b4').pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "margin": "xxl",
            "cornerRadius": "100px",
            "height": "72px",
            "width": "72px",
            "offsetStart": "110px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "text",
                "text": "{}".format(noobcoder.getContact('ucad303333969352466bfecd62089a1b4').displayName),
                "size": "md",
                "color": "#000000",
                "weight": "bold",
                "align": "center"
              },
              {
                "type": "box",
                "layout": "horizontal",
                "contents": [
                  {
                    "type": "filler"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "text",
                        "text": "Add Friend",
                        "size": "sm",
                        "color": "#Ffffff",
                        "align": "center"
                      }
                    ],
                    "borderWidth": "1px",
                    "backgroundColor": "#008000",
                    "action": {
                      "type": "uri",
                      "label": "action",
                      "uri": "http://line.me/ti/p/~gkada.line"
                    }
                  },
                  {
                    "type": "filler"
                  }
                ],
                "margin": "md"
              }
            ],
            "margin": "md"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "spacer",
                "size": "xxl"
              }
            ],
            "margin": "xxl"
          }
        ],
        "margin": "xxl"
      }
    ],
    "paddingAll": "0px"
  }}]}}
    sendTemplate(to,data)
def debug():
    get_profile_time_start = time.time()
    get_profile = noobcoder.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = noobcoder.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = noobcoder.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " 「 Debug 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def powpow():
    Headers = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
    "x-lal": "ja-US_US",
    }
    return Headers
def getmytoken():
    Headers = {
    'User-Agent': "Line/8.9.1",
    'X-Line-Application': "IOSIPAD\t11.2.5\tiPhone X\t11.2.5",
    "x-lal": "ja-US_US",
    }
    return Headers
def shareall(to, text):
    lol = noobcoder.getGroupIdsJoined()
    for group in lol:
        noobcoder.sendPostToTalk(group, text)
    noobcoder.sendMessage(to, "Share in {} group".format(str(len(lol))))
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#=====================================================================
#def Template(to):
def sendMessageCustom(to, text, icon , name):
    annda = {'MSG_SENDER_ICON': icon,
        'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, text, contentMetadata=annda)
def sendMessageCustomContact(to, icon, name, mid):
    annda = { 'mid': mid,
    'MSG_SENDER_ICON': icon,
    'MSG_SENDER_NAME':  name,
    }
    noobcoder.sendMessage(to, '', annda, 13)

def B64e(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64encode(url.encode()).decode())

def B64d(to, url):
	import base64
	return noobcoder.sendMessage(to, base64.b64decode(url.encode()).decode())
	
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            noobcoder.sendMessage(to, text, {'MSG_SENDER_NAME': noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    noobcoder.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(noobcoder.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = noobcoder.genOBSParams({'oid': noobcoderMID, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = noobcoder.server.postContent('{}/talk/vp/upload.nhn'.format(str(noobcoder.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        noobcoder.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("noobcoderWasHere.mp4")
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)
        
def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()
	
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        noobcoder.sendMessage(to, textx, {'MSG_SENDER_NAME': client.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + noobcoder.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def logError(text):
    noobcoder.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("noobcoder/errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
def likeNotify(to):
    true = True
    data = {
        "type": "flex",
        "altText": "LIKE NOTIFY",
        "contents": {
            "type": "bubble",
            "styles": {
                "header": {
                    "backgroundColor": "#333333"
                },
                "hero": {
                    "backgroundColor": "#333333"
                },
                "body": {
                    "backgroundColor": "#FFFFFF",
                    "separator": true,
                    "separatorColor": "#FFFFFF"
                },
                "footer": {
                    "backgroundColor": "#333333",
                    "separator": true
                }
            },
            "body": {
                "type": "box",
                "layout": "vertical",
                "contents": [
                    {
                        "type": "text",
                        "text": "LIKE NOTIFY",
                        "weight": "bold",
                        "size": "xxl",
                        "color": "#000000",
                        "margin": "md"
                    },
                    {
                        "type": "text",
                        "text": "Your Post Has Been Liked",
                        "size": "xs",
                        "color": "#aaaaaa",
                        "wrap": true
                    },
                    {
                        "type": "separator",
                        "margin": "xxl"
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "margin": "xxl",
                        "spacing": "sm",
                        "contents": [
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "RENTAL SELFBOT",
                                        "weight": "bold",
                                        "color": "#000000",
                                        "size": "sm",
                                        "flex": 0
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "PAYMENT :",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "• OVO",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    },
                                    {
                                        "type": "text",
                                        "text": "40K",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "align": "end"
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "• T-SEL",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    },
                                    {
                                        "type": "text",
                                        "text": "50K",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "align": "end"
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "• PAYPAL",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    },
                                    {
                                        "type": "text",
                                        "text": "4$",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "align": "end"
                                    }
                                ]
                            },
                            {
                                "type": "box",
                                "layout": "horizontal",
                                "contents": [
                                    {
                                        "type": "text",
                                        "text": "Get free 100 accounts autolike bots",
                                        "size": "sm",
                                        "color": "#aaaaaa",
                                        "flex": 0
                                    }
                                ]
                            },
                            {
                                "type": "separator",
                                "margin":"md"
                            }
                        ]
                    },
                    {
                        "type": "box",
                        "layout": "horizontal",
                        "margin": "md",
                        "contents": [
                            {
                                "type": "text",
                                "text": "Wanna Order ?",
                                "size": "xs",
                                "color": "#000000",
                                "flex": 0
                            }
                        ]
                    },
                    {
                        "type": "box",
                        "layout": "vertical",
                        "margin": "md",
                        "contents": [
                            {
                                "type": "spacer",
                                "size": "xl"
                            },
                            {
                                "type": "button",
                                "action": {
                                    "type": "uri",
                                    "label": "Click Here",
                                    "uri": "line://ti/p/~justanolep"
                                },
                                "style": "primary",
                                "color": "#000000"
                            }
                        ]
                    }
                ]
            }
        }
    }
    sendTemplate(to, data)
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def backupData():
    try:
        backup = settings
        f = codecs.open('noobcoder/temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('noobcoder/wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = premium
        f = codecs.open('noobcoder/user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = java
        f = codecs.open('noobcoder/java.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
def bcTemplate(gr, data):
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1643727178-0XPGAaRX', xyzz)
    token = noobcoder.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
	
def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 0:
            return
        
        if op.type == 11:
            if op.param1 in protectqr:
                wait["blacklist"][op.param2] = True
                try:
                    if noobcoder.getGroup(op.param1).preventedJoinByTicket == False:
                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                            noobcoder.reissueGroupTicket(op.param1)
                            X = noobcoder.getGroup(op.param1)
                            X.preventedJoinByTicket = True
                            Ticket = noobcoder.reissueGroupTicket(op.param1)
                            sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                            sw.kickoutFromGroup(op.param1,[op.param2])
                            sw.leaveGroup(op.param1)
                            noobcoder.updateGroup(X)
                except:
                    try:
                        if ki.getGroup(op.param1).preventedJoinByTicket == False:
                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                ki.reissueGroupTicket(op.param1)
                                X = ki.getGroup(op.param1)
                                X.preventedJoinByTicket = True
                                Ticket = ki.reissueGroupTicket(op.param1)
                                sx.acceptGroupInvitationByTicket(op.param1,Ticket)
                                sx.kickoutFromGroup(op.param1,[op.param2])
                                sx.leaveGroup(op.param1)
                                ki.updateGroup(X)
                    except:
                        try:
                            if kk.getGroup(op.param1).preventedJoinByTicket == False:
                                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                    kk.reissueGroupTicket(op.param1)
                                    X = kk.getGroup(op.param1)
                                    X.preventedJoinByTicket = True
                                    Ticket = kk.reissueGroupTicket(op.param1)
                                    sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    sw.kickoutFromGroup(op.param1,[op.param2])
                                    sw.leaveGroup(op.param1)
                                    kk.updateGroup(X)
                        except:
                            try:
                                if kc.getGroup(op.param1).preventedJoinByTicket == False:
                                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                        kc.reissueGroupTicket(op.param1)
                                        X = kc.getGroup(op.param1)
                                        X.preventedJoinByTicket = True
                                        Ticket = kc.reissueGroupTicket(op.param1)
                                        sx.acceptGroupInvitationByTicket(op.param1,Ticket)
                                        sx.kickoutFromGroup(op.param1,[op.param2])
                                        sx.leaveGroup(op.param1)
                                        kc.updateGroup(X)
                            except:
                                try:
                                    if km.getGroup(op.param1).preventedJoinByTicket == False:
                                        if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                            km.reissueGroupTicket(op.param1)
                                            X = km.getGroup(op.param1)
                                            X.preventedJoinByTicket = True
                                            Ticket = km.reissueGroupTicket(op.param1)
                                            sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                            sw.kickoutFromGroup(op.param1,[op.param2])
                                            km.updateGroup(X)
                                except:
                                    try:
                                        if kb.getGroup(op.param1).preventedJoinByTicket == False:
                                            if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                                kb.reissueGroupTicket(op.param1)
                                                X = kb.getGroup(op.param1)
                                                X.preventedJoinByTicket = True
                                                Ticket = kb.reissueGroupTicket(op.param1)
                                                sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                sw.kickoutFromGroup(op.param1,[op.param2])
                                                kb.updateGroup(X)
                                    except:
                                        try:
                                            if kn.getGroup(op.param1).preventedJoinByTicket == False:
                                                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                                                    kb.reissueGroupTicket(op.param1)
                                                    X = kb.getGroup(op.param1)
                                                    X.preventedJoinByTicket = True
                                                    Ticket = kb.reissueGroupTicket(op.param1)
                                                    sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                                    sw.kickoutFromGroup(op.param1,[op.param2])
                                                    kn.updateGroup(X)
                                        except:
                                            pass
        if op.type == 13:
            if mid in op.param3:
                if wait["autoLeave"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        noobcoder.acceptGroupInvitation(op.param1)
                        ginfo = noobcoder.getGroup(op.param1)
                        noobcoder.sendMessage(op.param1,"Fuck you\n Group " +str(ginfo.name))
                        noobcoder.leaveGroup(op.param1)
                    else:
                        noobcoder.acceptGroupInvitation(op.param1)
                        ginfo = noobcoder.getGroup(op.param1)
                        noobcoder.sendMessage(op.param1,"Hai " + str(ginfo.name))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    noobcoder.acceptGroupInvitation(op.param1)
                    xyz = noobcoder.getGroup(op.param1)
                    mem = [c.mid for c in xyz.members]
                    targets = []
                    for x in mem:
                            if x not in ["u9d03d5098465a5f8683e71d20e350022",noobcoder.profile.mid]:targets.append(x)
                    if targets:
                            imnoob = 'dual.js gid={} token={} app={}'.format(op.param1, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                    for target in targets:
                            imnoob += ' uid={}'.format(target)
                            success = execute_js(imnoob)
                    if success:noobcoder.sendMessage(op.param1, "Success kick %i members." % len(targets))
                    else:noobcoder.sendMessage(op.param1, "Failed kick %i members." % len(targets))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    kk.acceptGroupInvitation(op.param1)
                    group = kk.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                        #if success:kk.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                        #else:kk.sendMessage(op.param1, "Failed kick %i members." % len(cmd))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    kc.acceptGroupInvitation(op.param1)
                    group = kc.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                        #if success:kc.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                        #else:kc.sendMessage(op.param1, "Failed kick %i members." % len(cmd))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    km.acceptGroupInvitation(op.param1)
                    group = km.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                        #if success:km.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                        #else:km.sendMessage(op.param1, "Failed kick %i members." % len(cmd))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    kb.acceptGroupInvitation(op.param1)
                    group = kb.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                      #  if success:kb.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                       # else:kb.sendMessage(op.param1, "Failed kick %i members." % len(cmd))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    kn.acceptGroupInvitation(op.param1)
                    group = kn.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                    #    if success:kn.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                     #   else:kn.sendMessage(op.param1, "Failed kick %i members." % len(cmd))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    ko.acceptGroupInvitation(op.param1)
                    group = ko.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                        #if success:ko.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                       # else:ko.sendMessage(op.param1, "Failed kick %i members." % len(cmd))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    kw.acceptGroupInvitation(op.param1)
                    group = kw.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                      #  if success:kw.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                     #   else:kw.sendMessage(op.param1, "Failed kick %i members." % len(cmd))
        if op.type == 13:
            if mid in op.param3:
                if wait["InCiak"] == True:
                    ke.acceptGroupInvitation(op.param1)
                    group = ke.getGroup(op.param1)
                    cmd = 'dual.js gid={} token={}'.format(op.param1,noobcoder.authToken)
                    members = [o.mid for o in group.members if o.mid not in admin and o.mid not in Bots]
                    for o in group.members:
                        if o.mid not in admin and o.mid not in Bots:
                            cmd += ' uid={}'.format(o.mid)
                            cmd += ' uik={}'.format(o.mid)
                            success = execute_js(cmd)
                    #    if success:ke.sendMessage(op.param1, "Success kick %i members." % len(cmd))
                       # else:ke.sendMessage(op.param1, "Failed kick %i members." % len(cmd))

        if op.type == 13:
            if mid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        noobcoder.acceptGroupInvitation(op.param1)
                        ginfo = noobcoder.getGroup(op.param1)
                        noobcoder.sendMessage(op.param1,"Helloooo!!! " +str(ginfo.name))
                    else:
                        noobcoder.acceptGroupInvitation(op.param1)
                        ginfo = noobcoder.getGroup(op.param1)
                        noobcoder.sendMessage(op.param1,"Helloooo!!! " + str(ginfo.name))
            if Amid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ki.acceptGroupInvitation(op.param1)
                        ginfo = ki.getGroup(op.param1)
                        ki.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        ki.leaveGroup(op.param1)
                    else:
                        ki.acceptGroupInvitation(op.param1)
                        ginfo = ki.getGroup(op.param1)
                        ki.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Bmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kk.acceptGroupInvitation(op.param1)
                        ginfo = kk.getGroup(op.param1)
                        ki.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        kk.leaveGroup(op.param1)
                    else:
                        kk.acceptGroupInvitation(op.param1)
                        ginfo = kk.getGroup(op.param1)
                        kk.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Cmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kc.acceptGroupInvitation(op.param1)
                        ginfo = kc.getGroup(op.param1)
                        kc.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        kc.leaveGroup(op.param1)
                    else:
                        kc.acceptGroupInvitation(op.param1)
                        ginfo = kc.getGroup(op.param1)
                        kc.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Dmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        km.acceptGroupInvitation(op.param1)
                        ginfo = km.getGroup(op.param1)
                        km.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        km.leaveGroup(op.param1)
                    else:
                        kb.acceptGroupInvitation(op.param1)
                        ginfo = km.getGroup(op.param1)
                        kb.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Emid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kb.acceptGroupInvitation(op.param1)
                        ginfo = kb.getGroup(op.param1)
                        kb.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        kb.leaveGroup(op.param1)
                    else:
                        kb.acceptGroupInvitation(op.param1)
                        ginfo = kb.getGroup(op.param1)
                        kb.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Fmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kn.acceptGroupInvitation(op.param1)
                        ginfo = kn.getGroup(op.param1)
                        kn.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        kn.leaveGroup(op.param1)
                    else:
                        kn.acceptGroupInvitation(op.param1)
                        ginfo = kn.getGroup(op.param1)
                        kn.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Gmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ko.acceptGroupInvitation(op.param1)
                        ginfo = ko.getGroup(op.param1)
                        ko.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        ko.leaveGroup(op.param1)
                    else:
                        ko.acceptGroupInvitation(op.param1)
                        ginfo = ko.getGroup(op.param1)
                        ko.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Hmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        kw.acceptGroupInvitation(op.param1)
                        ginfo = kw.getGroup(op.param1)
                        kw.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        kw.leaveGroup(op.param1)
                    else:
                        kw.acceptGroupInvitation(op.param1)
                        ginfo = kw.getGroup(op.param1)
                        kw.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Imid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ke.acceptGroupInvitation(op.param1)
                        ginfo = ke.getGroup(op.param1)
                        ke.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        ke.leaveGroup(op.param1)
                    else:
                        ke.acceptGroupInvitation(op.param1)
                        ginfo = ke.getGroup(op.param1)
                        ke.sendMessage(op.param1,"Hai " + str(ginfo.name))
            if Jmid in op.param3:
                if wait["autoJoin"] == True:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        ky.acceptGroupInvitation(op.param1)
                        ginfo = ky.getGroup(op.param1)
                        ky.sendMessage(op.param1,"whaaat???\n Group " +str(ginfo.name))
                        ky.leaveGroup(op.param1)
                    else:
                        ky.acceptGroupInvitation(op.param1)
                        ginfo = ky.getGroup(op.param1)
                        ky.sendMessage(op.param1,"Hai " + str(ginfo.name))

        if op.type == 13:
            if op.param1 in protectinvite:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        group = kn.getGroup(op.param1)
                        gMembMids = [contact.mid for contact in group.invitee]
                        for _mid in gMembMids:
                            kn.cancelGroupInvitation(op.param1,[_mid])
                            kn.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            group = ko.getGroup(op.param1)
                            gMembMids = [contact.mid for contact in group.invitee]
                            for _mid in gMembMids:
                                ko.cancelGroupInvitation(op.param1,[_mid])
                                ko.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                group = kw.getGroup(op.param1)
                                gMembMids = [contact.mid for contact in group.invitee]
                                for _mid in gMembMids:
                                    kw.cancelGroupInvitation(op.param1,[_mid])
                                    kw.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    group = ke.getGroup(op.param1)
                                    gMembMids = [contact.mid for contact in group.invitee]
                                    for _mid in gMembMids:
                                        ke.cancelGroupInvitation(op.param1,[_mid])
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    pass

        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 17:
            if op.param1 in welcome:
                if op.param2 in Bots:
                    pass
                ginfo = noobcoder.getGroup(op.param1)
                contact = noobcoder.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                noobcoder.sendImageWithURL(op.param1, image)

        if op.type == 17:
            if op.param1 in protectjoin:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 0:
            return
        if op.type == 5:
            if wait["autoAdd"] == True:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if (wait["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        noobcoder.sendText(op.param1, wait["message"])

        if op.type == 19:
            if op.param1 in protectkick:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                else:
                    pass

        if op.type == 19:
            try:
                if op.param1 in ghost:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        G = noobcoder.getGroup(op.param1)
                        G.preventedJoinByTicket = False
                        noobcoder.updateGroup(G)
                        invsend = 0
                        Ticket = noobcoder.reissueGroupTicket(op.param1)
                        sw.acceptGroupInvitationByTicket(op.param1,Ticket)
                        sw.kickoutFromGroup(op.param1,[op.param2])
                        sw.leaveGroup(op.param1)
                        X = noobcoder.getGroup(op.param1)
                        X.preventedJoinByTicket = True
                        noobcoder.updateGroup(X)
            except:
                pass             
                
        if op.type == 19:
            try:
                if op.param1 in protectantijs:
                  if op.param3 in mid:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        js.acceptGroupInvitation(op.param1)
                        G = js.getGroup(op.param1)
                        G.prevenJoinByTicket = False
                        js.updateGroup(G)
                        Ticket = js.reissueGroupTicket(op.param1)
                        random.choice(KAC).acceptGroupInvitationByTicket(op.param1,Ticket)
                        js.kickoutFromGroup(op.param1,[op.param2])
                        G.prevenJoinByTicket = True
                        js.updateGroup(G)
                        wait["blacklist"][op.param2] = True
                        js.leaveGroup(op.param1)
                        noobcoder.inviteIntoGroup(op.param1,[JSmid])
                        noobcoder.inviteIntoGroup(op.param1,[admin])
                    else:
                       pass
                        
                if op.param3 in JSmid:
                    if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                        noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        noobcoder.findAndAddContactsByMid(op.param3)
                        noobcoder.inviteIntoGroup(op.param1,[JSmid])
                        noobcoder.sendMessage(op.param1,"=AntiJS Invited=")
                    else:
                        noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        noobcoder.findAndAddContactsByMid(op.param3)
                        noobcoder.inviteIntoGroup(op.param1,[JSmid])
                        noobcoder.sendMessage(op.param1,"=AntiJS Invited=")
                        
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    if op.param3 in admin:
                        if op.param1 in protectantijs:
                            wait["blacklist"][op.param2] = True
                            noobcoder.kickoutFromGroup(op.param1,[op.param2])
                            noobcoder.findAndAddContactsByMid(op.param3)
                            noobcoder.inviteIntoGroup(op.param1,[op.param3])
                            noobcoder.sendMessage(op.param1,"=Admin Invited=")
                else:
                    pass
            except:
                pass

        if op.type == 32:
            if op.param1 in protectcancel:
                if op.param2 not in Bots and op.param2 not in owner and op.param2 not in admin and op.param2 not in staff:
                    wait["blacklist"][op.param2] = True
                    try:
                        if op.param3 not in wait["blacklist"]:
                            random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                    except:
                           pass
                           
                return

        if op.type == 19:
            if mid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        noobcoder.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kk.kickoutFromGroup(op.param1,[op.param2])
                            kk.inviteIntoGroup(op.param1,[op.param3])
                            noobcoder.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                noobcoder.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = ki.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                    ki.updateGroup(G)
                                    Ticket = ki.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = ki.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    ki.updateGroup(G)
                                    Ticket = ki.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                        noobcoder.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kk.kickoutFromGroup(op.param1,[op.param2])
                                            kk.inviteIntoGroup(op.param1,[op.param3])
                                            noobcoder.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Amid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        kk.kickoutFromGroup(op.param1,[op.param2])
                        kk.inviteIntoGroup(op.param1,[op.param3])
                        ki.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            ki.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                km.kickoutFromGroup(op.param1,[op.param2])
                                km.inviteIntoGroup(op.param1,[op.param3])
                                ki.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kk.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kk.kickoutFromGroup(op.param1,[op.param2])
                                    kk.updateGroup(G)
                                    Ticket = kk.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kk.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kk.updateGroup(G)
                                    Ticket = kk.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kk.kickoutFromGroup(op.param1,[op.param2])
                                        kk.inviteIntoGroup(op.param1,[op.param3])
                                        ki.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                            ki.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Bmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        kc.kickoutFromGroup(op.param1,[op.param2])
                        kc.inviteIntoGroup(op.param1,[op.param3])
                        kk.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            km.kickoutFromGroup(op.param1,[op.param2])
                            km.inviteIntoGroup(op.param1,[op.param3])
                            kk.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                                kk.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kc.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.updateGroup(G)
                                    Ticket = kc.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kc.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kc.updateGroup(G)
                                    Ticket = kc.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                        kk.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            km.kickoutFromGroup(op.param1,[op.param2])
                                            km.inviteIntoGroup(op.param1,[op.param3])
                                            kk.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Cmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        km.kickoutFromGroup(op.param1,[op.param2])
                        km.inviteIntoGroup(op.param1,[op.param3])
                        kc.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                            kc.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kn.kickoutFromGroup(op.param1,[op.param2])
                                kn.inviteIntoGroup(op.param1,[op.param3])
                                kc.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = km.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    km.kickoutFromGroup(op.param1,[op.param2])
                                    km.updateGroup(G)
                                    Ticket = km.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = km.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    km.updateGroup(G)
                                    Ticket = km.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        km.kickoutFromGroup(op.param1,[op.param2])
                                        km.inviteIntoGroup(op.param1,[op.param3])
                                        kc.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kb.kickoutFromGroup(op.param1,[op.param2])
                                            kb.inviteIntoGroup(op.param1,[op.param3])
                                            kc.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
            if Dmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        kb.kickoutFromGroup(op.param1,[op.param2])
                        kb.inviteIntoGroup(op.param1,[op.param3])
                        km.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kn.kickoutFromGroup(op.param1,[op.param2])
                            kn.inviteIntoGroup(op.param1,[op.param3])
                            km.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ko.kickoutFromGroup(op.param1,[op.param2])
                                ko.inviteIntoGroup(op.param1,[op.param3])
                                km.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kb.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                    kb.updateGroup(G)
                                    Ticket = kb.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kb.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kb.updateGroup(G)
                                    Ticket = kb.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                        km.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kn.kickoutFromGroup(op.param1,[op.param2])
                                            kn.inviteIntoGroup(op.param1,[op.param3])
                                            km.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Emid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        kn.kickoutFromGroup(op.param1,[op.param2])
                        kn.inviteIntoGroup(op.param1,[op.param3])
                        kb.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ko.kickoutFromGroup(op.param1,[op.param2])
                            ko.inviteIntoGroup(op.param1,[op.param3])
                            kb.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kw.kickoutFromGroup(op.param1,[op.param2])
                                kw.inviteIntoGroup(op.param1,[op.param3])
                                kb.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kn.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kn.kickoutFromGroup(op.param1,[op.param2])
                                    kn.updateGroup(G)
                                    Ticket = kn.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kn.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kn.updateGroup(G)
                                    Ticket = kn.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kn.kickoutFromGroup(op.param1,[op.param2])
                                        kn.inviteIntoGroup(op.param1,[op.param3])
                                        kb.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ko.kickoutFromGroup(op.param1,[op.param2])
                                            ko.inviteIntoGroup(op.param1,[op.param3])
                                            kb.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Fmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        ko.kickoutFromGroup(op.param1,[op.param2])
                        ko.inviteIntoGroup(op.param1,[op.param3])
                        kn.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kw.kickoutFromGroup(op.param1,[op.param2])
                            kw.inviteIntoGroup(op.param1,[op.param3])
                            kn.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ke.kickoutFromGroup(op.param1,[op.param2])
                                ke.inviteIntoGroup(op.param1,[op.param3])
                                kn.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = ko.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    ko.kickoutFromGroup(op.param1,[op.param2])
                                    ko.updateGroup(G)
                                    Ticket = ko.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = ko.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    ko.updateGroup(G)
                                    Ticket = ko.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        ko.kickoutFromGroup(op.param1,[op.param2])
                                        ko.inviteIntoGroup(op.param1,[op.param3])
                                        kn.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kw.kickoutFromGroup(op.param1,[op.param2])
                                            kw.inviteIntoGroup(op.param1,[op.param3])
                                            kn.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
            if Gmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        kw.kickoutFromGroup(op.param1,[op.param2])
                        kw.inviteIntoGroup(op.param1,[op.param3])
                        ko.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ke.kickoutFromGroup(op.param1,[op.param2])
                            ke.inviteIntoGroup(op.param1,[op.param3])
                            ko.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ky.kickoutFromGroup(op.param1,[op.param2])
                                ky.inviteIntoGroup(op.param1,[op.param3])
                                ko.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = kw.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    kw.kickoutFromGroup(op.param1,[op.param2])
                                    kw.updateGroup(G)
                                    Ticket = kw.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = kw.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    kw.updateGroup(G)
                                    Ticket = kw.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        kw.kickoutFromGroup(op.param1,[op.param2])
                                        kw.inviteIntoGroup(op.param1,[op.param3])
                                        ko.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                            ko.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Hmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        ke.kickoutFromGroup(op.param1,[op.param2])
                        ke.inviteIntoGroup(op.param1,[op.param3])
                        kw.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ky.kickoutFromGroup(op.param1,[op.param2])
                            ky.inviteIntoGroup(op.param1,[op.param3])
                            kw.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                noobcoder.kickoutFromGroup(op.param1,[op.param2])
                                noobcoder.inviteIntoGroup(op.param1,[op.param3])
                                kw.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = ke.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                    ke.updateGroup(G)
                                    Ticket = ke.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = ke.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    ke.updateGroup(G)
                                    Ticket = ke.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                        kw.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ky.kickoutFromGroup(op.param1,[op.param2])
                                            ky.inviteIntoGroup(op.param1,[op.param3])
                                            kw.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Imid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        ky.kickoutFromGroup(op.param1,[op.param2])
                        ky.inviteIntoGroup(op.param1,[op.param3])
                        ke.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            noobcoder.kickoutFromGroup(op.param1,[op.param2])
                            noobcoder.inviteIntoGroup(op.param1,[op.param3])
                            ke.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ki.kickoutFromGroup(op.param1,[op.param2])
                                ki.inviteIntoGroup(op.param1,[op.param3])
                                ke.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = ky.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    ky.kickoutFromGroup(op.param1,[op.param2])
                                    ky.updateGroup(G)
                                    Ticket = ky.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = ky.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    ky.updateGroup(G)
                                    Ticket = ky.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        ky.kickoutFromGroup(op.param1,[op.param2])
                                        ky.inviteIntoGroup(op.param1,[op.param3])
                                        ke.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            noobcoder.kickoutFromGroup(op.param1,[op.param2])
                                            noobcoder.inviteIntoGroup(op.param1,[op.param3])
                                            ke.acceptGroupInvitation(op.param1)
                                        except:
                                            pass
                return

            if Jmid in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        noobcoder.kickoutFromGroup(op.param1,[op.param2])
                        noobcoder.inviteIntoGroup(op.param1,[op.param3])
                        ky.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ki.kickoutFromGroup(op.param1,[op.param2])
                            ki.inviteIntoGroup(op.param1,[op.param3])
                            ky.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kk.kickoutFromGroup(op.param1,[op.param2])
                                kk.inviteIntoGroup(op.param1,[op.param3])
                                ky.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    G = noobcoder.getGroup(op.param1)
                                    G.preventedJoinByTicket = False
                                    noobcoder.kickoutFromGroup(op.param1,[op.param2])
                                    noobcoder.updateGroup(G)
                                    Ticket = noobcoder.reissueGroupTicket(op.param1)
                                    noobcoder.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ki.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kk.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kc.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    km.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kb.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kn.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ko.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    kw.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ke.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    ky.acceptGroupInvitationByTicket(op.param1,Ticket)
                                    G = noobcoder.getGroup(op.param1)
                                    G.preventedJoinByTicket = True
                                    noobcoder.updateGroup(G)
                                    Ticket = noobcoder.reissueGroupTicket(op.param1)
                                except:
                                    try:
                                        noobcoder.kickoutFromGroup(op.param1,[op.param2])
                                        noobcoder.inviteIntoGroup(op.param1,[op.param3])
                                        ky.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                            ky.acceptGroupInvitation(op.param1)
                                        except:
                                            pass                 
                return

            if admin in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                        random.choice(ABC).findAndAddContactsByMid(op.param1,admin)
                        random.choice(ABC).inviteIntoGroup(op.param1,admin)
                    except:
                        pass

                return

            if staff in op.param3:
                if op.param2 in Bots:
                    pass
                if op.param2 in owner:
                    pass
                if op.param2 in admin:
                    pass
                if op.param2 in staff:
                    pass
                else:
                    wait["blacklist"][op.param2] = True
                    try:
                        random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
                        random.choice(ABC).findAndAddContactsByMid(op.param1,staff)
                        random.choice(ABC).inviteIntoGroup(op.param1,staff)
                    except:
                        pass

                return

        if op.type == 55:
            try:
                if op.param1 in Setmain["ARreadPoint"]:
                   if op.param2 in Setmain["ARreadMember"][op.param1]:
                       pass
                   else:
                       Setmain["ARreadMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass

            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = noobcoder.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
                        contact = noobcoder.getContact(op.param2)
                        #image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                        noobcoder.sendImageWithURL(op.param1, image)                        
                        
        if op.type == 55:
            if op.param2 in wait["blacklist"]:
                random.choice(ABC).kickoutFromGroup(op.param1,[op.param2])
            else:
                pass

        if op.type == 26:
           if wait["selfbot"] == True:
               msg = op.message
               if msg._from not in Bots:
                 if wait["talkban"] == True:
                   if msg._from in wait["Talkblacklist"]:
                      try:
                          random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                      except:
                          try:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
                          except:
                              random.choice(ABC).kickoutFromGroup(msg.to, [msg._from])
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["detectMention"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           noobcoder.sendMessage(msg.to, wait["Respontag"])
                           noobcoder.sendMessage(msg.to, None, contentMetadata={"STKID":"7839705","STKPKGID":"1192862","STKVER":"1"}, contentType=7)
                           break
               if 'MENTION' in msg.contentMetadata.keys() != None:
                 if wait["Mentionkick"] == True:
                   name = re.findall(r'@(\w+)', msg.text)
                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                   mentionees = mention['MENTIONEES']
                   for mention in mentionees:
                        if mention ['M'] in Bots:
                           noobcoder.mentiontag(msg.to,[msg._from])
                           noobcoder.sendMessage(msg.to, "Jangan tag saya....")
                           noobcoder.kickoutFromGroup(msg.to, [msg._from])
                           break
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    noobcoder.sendMessage(msg.to,"「Cek ID Sticker」\n❧STKID : " + msg.contentMetadata["STKID"] + "\n❧STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n❧STKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    noobcoder.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = noobcoder.getContact(msg.contentMetadata["mid"])
                        path = noobcoder.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        noobcoder.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        noobcoder.sendImageWithURL(msg.to, image)

        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if wait["sticker"] == True:
                    msg.contentType = 0
                    noobcoder.sendMessage(msg.to,"STKID : " + msg.contentMetadata["STKID"] + "\nSTKPKGID : " + msg.contentMetadata["STKPKGID"] + "\nSTKVER : " + msg.contentMetadata["STKVER"]+ "\n\n「Link Sticker」" + "\nline://shop/detail/" + msg.contentMetadata["STKPKGID"])
               if msg.contentType == 13:
                 if wait["contact"] == True:
                    msg.contentType = 0
                    noobcoder.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = noobcoder.getContact(msg.contentMetadata["mid"])
                        path = noobcoder.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        noobcoder.sendMessage(msg.to,"❧Nama : " + msg.contentMetadata["displayName"] + "\n❧MID : " + msg.contentMetadata["mid"] + "\n❧Status Msg : " + contact.statusMessage + "\n❧Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                        noobcoder.sendImageWithURL(msg.to, image)
#ADD Bots
               if msg.contentType == 13:
                 if msg._from in admin:
                  if wait["addbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        noobcoder.sendMessage(msg.to,"Contact add bot")
                        wait["addbots"] = True
                    else:
                        Bots.append(msg.contentMetadata["mid"])
                        wait["addbots"] = True
                        noobcoder.sendMessage(msg.to,"done add bot")
                 if wait["dellbots"] == True:
                    if msg.contentMetadata["mid"] in Bots:
                        Bots.remove(msg.contentMetadata["mid"])
                        noobcoder.sendMessage(msg.to,"done dell bot")
                    else:
                        wait["dellbots"] = True
                        noobcoder.sendMessage(msg.to,"was bot ")
#ADD STAFF
                 if msg._from in admin:
                  if wait["addstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        noobcoder.sendMessage(msg.to,"Contact itu sudah jadi staff")
                        wait["addstaff"] = True
                    else:
                        staff.append(msg.contentMetadata["mid"])
                        wait["addstaff"] = True
                        noobcoder.sendMessage(msg.to,"Done add tostaff")
                 if wait["dellstaff"] == True:
                    if msg.contentMetadata["mid"] in staff:
                        staff.remove(msg.contentMetadata["mid"])
                        noobcoder.sendMessage(msg.to,"Done dell from staff")
                        wait["dellstaff"] = True
                    else:
                        wait["dellstaff"] = True
                        noobcoder.sendMessage(msg.to,"was staff")
#ADD ADMIN
                 if msg._from in admin:
                  if wait["addadmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        noobcoder.sendMessage(msg.to,"was admin")
                        wait["addadmin"] = True
                    else:
                        admin.append(msg.contentMetadata["mid"])
                        wait["addadmin"] = True
                        noobcoder.sendMessage(msg.to,"Done add toadmin")
                 if wait["delladmin"] == True:
                    if msg.contentMetadata["mid"] in admin:
                        admin.remove(msg.contentMetadata["mid"])
                        noobcoder.sendMessage(msg.to,"Done dell from admin")
                    else:
                        wait["delladmin"] = True
                        noobcoder.sendMessage(msg.to,"was admin")
#ADD BLACKLIST
                 if msg._from in admin:
                  if wait["wblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        noobcoder.sendMessage(msg.to,"Contact itu sudah ada di blacklist")
                        wait["wblacklist"] = True
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = True
                        noobcoder.sendMessage(msg.to,"Done add toblacklist user")
                  if wait["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        noobcoder.sendMessage(msg.to,"Done dell from blacklist user")
                    else:
                        wait["dblacklist"] = True
                        noobcoder.sendMessage(msg.to,"Contact itu tidak ada di blacklist")
#TALKBAN
                 if msg._from in admin:
                  if wait["Talkwblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        noobcoder.sendMessage(msg.to,"Contact itu sudah ada di Talkban")
                        wait["Talkwblacklist"] = True
                    else:
                        wait["Talkblacklist"][msg.contentMetadata["mid"]] = True
                        wait["Talkwblacklist"] = True
                        noobcoder.sendMessage(msg.to,"Done add toTalkban user")
                  if wait["Talkdblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["Talkblacklist"]:
                        del wait["Talkblacklist"][msg.contentMetadata["mid"]]
                        noobcoder.sendMessage(msg.to,"Done dell from Talkban user")
                    else:
                        wait["Talkdblacklist"] = True
                        noobcoder.sendMessage(msg.to,"Contact itu tidak ada di Talkban")
#UPDATE FOTO
               if msg.contentType == 1:
                 if msg._from in admin:
                    if Setmain["Addimage"] == True:
                        msgid = msg.id
                        fotoo = "https://obs.line-apps.com/talk/m/download.nhn?oid="+msgid
                        headers = noobcoder.Talk.Headers
                        r = requests.get(fotoo, headers=headers, stream=True)
                        if r.status_code == 200:
                            path = os.path.join(os.path.dirname(__file__), 'dataPhotos/%s.jpg' % Setmain["Img"])
                            with open(path, 'wb') as fp:
                                shutil.copyfileobj(r.raw, fp)
                            noobcoder.sendText(msg.to, "Berhasil menambahkan gambar")
                        Setmain["Img"] = {}
                        Setmain["Addimage"] = False

               if msg.toType == 2:
                 if msg._from in admin:
                   if settings["groupPicture"] == True:
                     path = noobcoder.downloadObjectMsg(msg_id)
                     settings["groupPicture"] = False
                     noobcoder.updateGroupPicture(msg.to, path)
                     noobcoder.sendMessage(msg.to, "Berhasil mengubah foto group")

               if msg.contentType == 1:
                   if msg._from in admin:
                       if mid in Setmain["ARfoto"]:
                            path = noobcoder.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][mid]
                            noobcoder.updateProfilePicture(path)
                            noobcoder.sendMessage(msg.to,"Foto updateing")

               if msg.contentType == 1:
                 if msg._from in admin:
                        if Amid in Setmain["ARfoto"]:
                            path = ki.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Amid]
                            ki.updateProfilePicture(path)
                            ki.sendMessage(msg.to,"Foto updateing")
                        elif Bmid in Setmain["ARfoto"]:
                            path = kk.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Bmid]
                            kk.updateProfilePicture(path)
                            kk.sendMessage(msg.to,"Foto updateing")
                        elif Cmid in Setmain["ARfoto"]:
                            path = kc.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Cmid]
                            kc.updateProfilePicture(path)
                            kc.sendMessage(msg.to,"Foto updateing")
                        elif Zmid in Setmain["ARfoto"]:
                            path = sw.downloadObjectMsg(msg_id)
                            del Setmain["ARfoto"][Zmid]
                            sw.updateProfilePicture(path)
                            sw.sendMessage(msg.to,"Foto updateing")

               if msg.contentType == 1:
                 if msg._from in admin:
                   if settings["changePicture"] == True:
                     path1 = ki.downloadObjectMsg(msg_id)
                     path2 = kk.downloadObjectMsg(msg_id)
                     path3 = kc.downloadObjectMsg(msg_id)
                     settings["changePicture"] = False
                     ki.updateProfilePicture(path1)
                     ki.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     kk.updateProfilePicture(path2)
                     kk.sendMessage(msg.to, "Berhasil mengubah foto profile bot")
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to, "Berhasil mengubah foto profile bot")

               if msg.contentType == 0:
                    if Setmain["autoRead"] == True:
                        noobcoder.sendChatChecked(msg.to, msg_id)
                        ki.sendChatChecked(msg.to, msg_id)
                        kk.sendChatChecked(msg.to, msg_id)
                        kc.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == ".helpadmin":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               helpMessage = help()
                               noobcoder.sendMessage(msg.to, str(helpMessage))
                                                                                       
                        if cmd == "self on":
                            if msg._from in owner:
                                wait["selfbot"] = True
                                noobcoder.sendText(msg.to, "Selfbot on")
                                
                        elif cmd == "self off":
                            if msg._from in owner:
                                wait["selfbot"] = False
                                noobcoder.sendText(msg.to, "Selfbot off")
                                            
                        elif cmd == ".help2":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               helpMessage1 = helpbot()
                               noobcoder.sendMessage(msg.to, str(helpMessage1))

                        elif cmd == ".set":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                md = "❧ĐFamz_Botz_FI\n"
                                if wait["sticker"] == True: md+="❧Sticker「ON」\n"
                                else: md+="❧Sticker「OFF」\n"
                                if wait["contact"] == True: md+="❧Contact「ON」\n"
                                else: md+="❧Contact「OFF」\n"
                                if wait["talkban"] == True: md+="❧Talkban「ON」\n"
                                else: md+="❧Talkban「OFF」\n"
                                if wait["Mentionkick"] == True: md+="❧Notag「ON」\n"
                                else: md+="❧Notag「OFF」\n"
                                if wait["detectMention"] == True: md+="❧Respon「ON」\n"
                                else: md+="❧Respon「OFF」\n"
                                if wait["autoJoin"] == True: md+="❧Autojoin「ON」\n"
                                else: md+="❧Autojoin「OFF」\n"
                                if wait["InCiak"] == True: md+="❧nuke「ON」\n"
                                else: md+="❧nuke「OFF」\n"
                                if msg.to in welcome: md+="❧Welcome「ON」\n"
                                else: md+="❧Welcome「OFF」\n"
                                if wait["autoLeave"] == True: md+="❧Autoleave「ON」\n"
                                else: md+="❧Autoleave「OFF」\n"
                                if msg.to in protectqr: md+="❧Protecturl「ON」\n"
                                else: md+="❧Protecturl「OFF」\n"
                                if msg.to in protectjoin: md+="❧Protectjoin「ON」\n"
                                else: md+="❧Protectjoin「OFF」\n"
                                if msg.to in protectkick: md+="❧Protectkick「ON」\n"
                                else: md+="❧Protectkick「OFF」\n"
                                if msg.to in protectinvite: md+="❧Protectinvite「ON」\n"
                                else: md+="❧Protectinvite「OFF」\n"
                                if msg.to in protectcancel: md+="❧Protectcancel「ON」\n"
                                else: md+="❧Protectcancel「OFF」\n"
                                if msg.to in protectantijs: md+="❧Antijs「ON」\n"
                                else: md+="❧Antijs「OFF」\n"  
                                if msg.to in ghost: md+="❧Ghost「ON」\n"
                                else: md+="❧Ghost「OFF」\n"                                   
                                noobcoder.sendMessage(msg.to, md+"\nTime : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")

                        elif cmd == "creator" or text.lower() == 'creator':
                            if msg._from in admin:
                                noobcoder.sendText(msg.to,"Creator; Eric") 
                                ma = ""
                                for i in creator:
                                    ma = noobcoder.getContact(i)
                                    noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "about" or cmd == "informasi":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sendMention(msg.to, sender, "「 Type Selfbot 」\n")
                               noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': mid}, contentType=13)

                        elif cmd == "me" or text.lower() == 'me':
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               noobcoder.sendMessage1(msg)

                        elif text.lower() == "mid":
                               noobcoder.sendMessage(msg.to, msg._from)

                        elif ("Mid " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = noobcoder.getContact(key1)
                               noobcoder.sendMessage(msg.to, "Nama : "+str(mi.displayName)+"\nMID : " +key1)
                               noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)

                        elif ("Info " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = noobcoder.getContact(key1)
                               noobcoder.sendMessage(msg.to, "❧Nama : "+str(mi.displayName)+"\n❧Mid : " +key1+"\n❧Status Msg"+str(mi.statusMessage))
                               noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(noobcoder.getContact(key1)):
                                   noobcoder.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   noobcoder.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))

                        elif cmd == ".mybot":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': mid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Amid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Bmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Cmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Dmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Emid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Fmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Gmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Hmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Imid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Jmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Zmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': Xmid}
                               noobcoder.sendMessage1(msg)
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': JSmid}
                               noobcoder.sendMessage1(msg)

                        elif text.lower() == "hapus chat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   noobcoder.removeAllMessages(op.param2)
                               except:
                                   pass

                        elif text.lower() == ".rechat":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               try:
                                   noobcoder.removeAllMessages(op.param2)
                                   ki.removeAllMessages(op.param2)
                                   kk.removeAllMessages(op.param2)
                                   kc.removeAllMessages(op.param2)
                                   km.removeAllMessages(op.param2)
                                   kb.removeAllMessages(op.param2)
                                   kn.removeAllMessages(op.param2)
                                   ko.removeAllMessages(op.param2)
                                   kw.removeAllMessages(op.param2)
                                   ke.removeAllMessages(op.param2)
                                   ky.removeAllMessages(op.param2)
                                   noobcoder.sendText(msg.to,"Chat cleared...")
                               except:
                                   pass

                        elif cmd.startswith("broadcast: "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = noobcoder.getGroupIdsJoined()
                               for group in saya:
                                   noobcoder.sendMessage(group,"[ Broadcast ]\n" + str(pesan))

                        elif text.lower() == "mykey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               noobcoder.sendMessage(msg.to, "「Mykey」\nSetkey bot 「 " + str(Setmain["keyCommand"]) + " 」")
                               
                        elif cmd.startswith("setkey "):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   noobcoder.sendMessage(msg.to, "Set key")
                               else:
                                   Setmain["keyCommand"] = str(key).lower()
                                   noobcoder.sendMessage(msg.to, "「Setkey」\nSetkey「{}」".format(str(key).lower()))

                        elif text.lower() == "resetkey":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               Setmain["keyCommand"] = ""
                               noobcoder.sendMessage(msg.to, "「Setkey」\nSetkey Done")

                        elif cmd == "restart":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               noobcoder.sendMessage(msg.to, "Restarting...")
                               Setmain["restartPoint"] = msg.to
                               restartBot()
                               noobcoder.sendMessage(msg.to, "Done ...")
                            
                        elif cmd == "runtime":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               eltime = time.time() - mulai
                               bot = "Aktif " +waktu(eltime)
                               noobcoder.sendMessage(msg.to,bot)
                            
                        elif cmd == "ginfow":
                          if msg._from in admin:
                            try:
                                G = noobcoder.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                noobcoder.sendMessage(msg.to, "❧ĐPĶ Fams Grup Info\n\n❧Nama Group : {}".format(G.name)+ "\n❧ID Group : {}".format(G.id)+ "\n❧Pembuat : {}".format(G.creator.displayName)+ "\n❧Waktu Dibuat : {}".format(str(timeCreated))+ "\n❧Jumlah Member : {}".format(str(len(G.members)))+ "\n❧Jumlah Pending : {}".format(gPending)+ "\n❧Group Qr : {}".format(gQr)+ "\n❧Group Ticket : {}".format(gTicket))
                                noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                noobcoder.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                noobcoder.sendMessage(msg.to, str(e))

                        elif cmd.startswith(".ginfo "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = noobcoder.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "Createor has delet his account"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += " Group Info\n"
                                ret_ += "\n❧Name Group : {}".format(G.name)
                                ret_ += "\n❧ID Group : {}".format(G.id)
                                ret_ += "\n❧Createor : {}".format(gCreator)
                                ret_ += "\n❧Time create : {}".format(str(timeCreated))
                                ret_ += "\n❧Total Member : {}".format(str(len(G.members)))
                                ret_ += "\n❧Total Pending : {}".format(gPending)
                                ret_ += "\n❧Group Qr : {}".format(gQr)
                                ret_ += "\n❧Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                noobcoder.sendMessage(to, str(ret_))
                            except:
                                pass

                        elif cmd.startswith("infomem "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = noobcoder.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "❧"+ str(no) + ". " + mem.displayName
                                noobcoder.sendMessage(to,"❧Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except: 
                                pass

                        elif cmd.startswith("leave: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = noobcoder.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            for i in group:
                                ginfo = noobcoder.getGroup(i)
                                if ginfo == group:
                                    ki.leaveGroup(i)
                                    kk.leaveGroup(i)
                                    kc.leaveGroup(i)
                                    km.leaveGroup(i)
                                    kb.leaveGroup(i)
                                    kn.leaveGroup(i)
                                    ko.leaveGroup(i)
                                    kw.leaveGroup(i)
                                    ke.leaveGroup(i)
                                    ky.leaveGroup(i)
                                    noobcoder.sendMessage(msg.to,"Berhasil keluar di grup " +str(ginfo.name))

                        elif cmd == "fiendlist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = noobcoder.getAllContactIds()
                               for i in gid:
                                   G = noobcoder.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               noobcoder.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")

                        elif cmd == ".glist":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = noobcoder.getGroupIdsJoined()
                               for i in gid:
                                   G = noobcoder.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               noobcoder.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == ".glist1":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = ki.getGroupIdsJoined()
                               for i in gid:
                                   G = ki.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               ki.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == ".glist2":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = kk.getGroupIdsJoined()
                               for i in gid:
                                   G = kk.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kk.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == ".glist3":
                            if msg._from in admin:
                               ma = ""
                               a = 0
                               gid = kc.getGroupIdsJoined()
                               for i in gid:
                                   G = kc.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kc.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")

                        elif cmd == "open":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = noobcoder.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   noobcoder.updateGroup(X)
                                   noobcoder.sendMessage(msg.to, "Url Opened")

                        elif cmd == "close":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   X = noobcoder.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   noobcoder.updateGroup(X)
                                   noobcoder.sendMessage(msg.to, "Url Closed")

                        elif cmd == "url grup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                if msg.toType == 2:
                                   x = noobcoder.getGroup(msg.to)
                                   if x.preventedJoinByTicket == True:
                                      x.preventedJoinByTicket = False
                                      noobcoder.updateGroup(x)
                                   gurl = noobcoder.reissueGroupTicket(msg.to)
                                   noobcoder.sendMessage(msg.to, "Name : "+str(x.name)+ "\nUrl grup : http://line.me/R/ti/g/"+gurl)

#===========BOT UPDATE============#
                        elif cmd == "updategrup":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if msg.toType == 2:
                                settings["groupPicture"] = True
                                noobcoder.sendText(msg.to,"Send pict.....")

                        elif cmd == "updatebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                settings["changePicture"] = True
                                noobcoder.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "updatefoto":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                Setmain["ARfoto"][mid] = True
                                noobcoder.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot1up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Amid] = True
                                ki.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot2up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Bmid] = True
                                kk.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot3up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Cmid] = True
                                kc.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot4up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Dmid] = True
                                km.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot5up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Emid] = True
                                kb.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot6up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Fmid] = True
                                kn.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot7up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Gmid] = True
                                ko.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot8up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Hmid] = True
                                kw.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot9up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Imid] = True
                                ke.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "bot10up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Jmid] = True
                                ky.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "antijsup":
                            if msg._from in admin:
                                Setmain["ARfoto"][JSmid] = True
                                js.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "ghost1up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Zmid] = True
                                sw.sendText(msg.to,"Send pict.....")
                                
                        elif cmd == "ghost2up":
                            if msg._from in admin:
                                Setmain["ARfoto"][Xmid] = True
                                sx.sendText(msg.to,"Send pict.....")

                        elif cmd.startswith("myname: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ki.getProfile()
                                profile.displayName = string
                                ki.updateProfile(profile)
                                ki.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kk.getProfile()
                                profile.displayName = string
                                kk.updateProfile(profile)
                                kk.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kc.getProfile()
                                profile.displayName = string
                                kc.updateProfile(profile)
                                kc.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = km.getProfile()
                                profile.displayName = string
                                km.updateProfile(profile)
                                km.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kb.getProfile()
                                profile.displayName = string
                                kb.updateProfile(profile)
                                kb.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kn.getProfile()
                                profile.displayName = string
                                kn.updateProfile(profile)
                                kn.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ko.getProfile()
                                profile.displayName = string
                                ko.updateProfile(profile)
                                ko.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kw.getProfile()
                                profile.displayName = string
                                kw.updateProfile(profile)
                                kw.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ke.getProfile()
                                profile.displayName = string
                                ke.updateProfile(profile)
                                ke.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ky.getProfile()
                                profile.displayName = string
                                ky.updateProfile(profile)
                                ky.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = js.getProfile()
                                profile.displayName = string
                                js.updateProfile(profile)
                                js.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = sw.getProfile()
                                profile.displayName = string
                                sw.updateProfile(profile)
                                sw.sendMessage(msg.to,"Done " + string + "")

                        elif cmd.startswith("cn: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = sx.getProfile()
                                profile.displayName = string
                                sx.updateProfile(profile)
                                sx.sendMessage(msg.to,"Done " + string + "")

#===========BOT UPDATE============#
                        elif cmd == ".tag" or text.lower() == '😆':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               group = noobcoder.getGroup(msg.to)
                               nama = [contact.mid for contact in group.members]
                               nm1, nm2, nm3, nm4,nm5,nm6,nm7,nm8,nm9,nm10,nm11,nm12,nm13,nm14,nm15, jml = [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], len(nama)
                               if jml <= 20:
                                   mentionMembers(msg.to, nama)
                               if jml > 20 and jml < 40:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, len(nama)-1):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                               if jml > 40 and jml < 60:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, len(nama)-1):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                               if jml > 60 and jml < 80:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, len(nama)-1):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                               if jml > 80 and jml < 100:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, len(nama)-1):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                               if jml > 100 and jml < 120:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, len(nama)-1):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                               if jml > 120 and jml < 140:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, len(nama)-1):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                               if jml > 140 and jml < 160:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, len(nama)-1):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                               if jml > 160 and jml < 180:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (150, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, len(nama)-1):
                                       nm8 += [nama[q]]                                       
                                   mentionMembers(msg.to, nm9)
                               if jml > 160 and jml < 180:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, 179):
                                       nm9 += [nama[q]]
                                   mentionMembers(msg.to, nm9)
                                   for r in range (180, len(nama)-1):
                                       nm10 += [nama[r]]
                                   mentionMembers(msg.to, nm10)
                               if jml > 180 and jml < 200:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, 179):
                                       nm9 += [nama[q]]
                                   mentionMembers(msg.to, nm9)
                                   for r in range (180, 199):
                                       nm10 += [nama[r]]
                                   mentionMembers(msg.to, nm10)
                                   for s in range (200, len(nama)-1):
                                       nm11 += [nama[s]]
                                   mentionMembers(msg.to, nm11)
                               if jml > 200 and jml < 220:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, 179):
                                       nm9 += [nama[q]]
                                   mentionMembers(msg.to, nm9)
                                   for r in range (180, 199):
                                       nm10 += [nama[r]]
                                   mentionMembers(msg.to, nm10)
                                   for s in range (200, 219):
                                       nm11 += [nama[s]]
                                   mentionMembers(msg.to, nm11)
                                   for t in range (220, len(nama)-1):
                                       nm12 += [nama[t]]
                                   mentionMembers(msg.to, nm12)
                               if jml > 220 and jml < 239:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, 179):
                                       nm9 += [nama[q]]
                                   mentionMembers(msg.to, nm9)
                                   for r in range (180, 199):
                                       nm10 += [nama[r]]
                                   mentionMembers(msg.to, nm10)
                                   for s in range (200, 219):
                                       nm11 += [nama[s]]
                                   mentionMembers(msg.to, nm11)
                                   for t in range (220, 239):
                                       nm12 += [nama[t]]
                                   mentionMembers(msg.to, nm12)
                                   for u in range (240, len(nama)-1):
                                       nm13 += [nama[u]]
                                   mentionMembers(msg.to, nm13)
                               if jml > 240 and jml < 259:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, 179):
                                       nm9 += [nama[q]]
                                   mentionMembers(msg.to, nm9)
                                   for r in range (180, 199):
                                       nm10 += [nama[r]]
                                   mentionMembers(msg.to, nm10)
                                   for s in range (200, 219):
                                       nm11 += [nama[s]]
                                   mentionMembers(msg.to, nm11)
                                   for t in range (220, 239):
                                       nm12 += [nama[t]]
                                   mentionMembers(msg.to, nm12)
                                   for u in range (240, 259):
                                       nm13 += [nama[u]]
                                   mentionMembers(msg.to, nm13)
                                   for v in range (260, len(nama)-1):
                                       nm14 += [nama[v]]
                                   mentionMembers(msg.to, nm14)
                               if jml > 260 and jml < 279:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, 179):
                                       nm9 += [nama[q]]
                                   mentionMembers(msg.to, nm9)
                                   for r in range (180, 199):
                                       nm10 += [nama[r]]
                                   mentionMembers(msg.to, nm10)
                                   for s in range (200, 219):
                                       nm11 += [nama[s]]
                                   mentionMembers(msg.to, nm11)
                                   for t in range (220, 239):
                                       nm12 += [nama[t]]
                                   mentionMembers(msg.to, nm12)
                                   for u in range (240, 259):
                                       nm13 += [nama[u]]
                                   mentionMembers(msg.to, nm13)
                                   for v in range (260, 279):
                                       nm14 += [nama[v]]
                                   mentionMembers(msg.to, nm14)
                                   for w in range (280, len(nama)-1):
                                       nm15 += [nama[w]]
                                   mentionMembers(msg.to, nm15)
                               if jml > 280 and jml < 299:
                                   for i in range (0, 19):
                                       nm1 += [nama[i]]
                                   mentionMembers(msg.to, nm1)
                                   for j in range (20, 39):
                                       nm2 += [nama[j]]
                                   mentionMembers(msg.to, nm2)
                                   for k in range (40, 59):
                                       nm3 += [nama[k]]
                                   mentionMembers(msg.to, nm3)
                                   for l in range (60, 79):
                                       nm4 += [nama[l]]
                                   mentionMembers(msg.to, nm4)
                                   for m in range (80, 99):
                                       nm5 += [nama[m]]
                                   mentionMembers(msg.to, nm5)
                                   for n in range (100, 119):
                                       nm6 += [nama[n]]
                                   mentionMembers(msg.to, nm6)
                                   for o in range (120, 139):
                                       nm7 += [nama[o]]
                                   mentionMembers(msg.to, nm7)
                                   for p in range (140, 159):
                                       nm8 += [nama[p]]
                                   mentionMembers(msg.to, nm8)
                                   for q in range (160, 179):
                                       nm9 += [nama[q]]
                                   mentionMembers(msg.to, nm9)
                                   for r in range (180, 199):
                                       nm10 += [nama[r]]
                                   mentionMembers(msg.to, nm10)
                                   for s in range (200, 219):
                                       nm11 += [nama[s]]
                                   mentionMembers(msg.to, nm11)
                                   for t in range (220, 239):
                                       nm12 += [nama[t]]
                                   mentionMembers(msg.to, nm12)
                                   for u in range (240, 259):
                                       nm13 += [nama[u]]
                                   mentionMembers(msg.to, nm13)
                                   for v in range (260, 279):
                                       nm14 += [nama[v]]
                                   mentionMembers(msg.to, nm14)
                                   for w in range (280, 299):
                                       nm15 += [nama[w]]
                                   mentionMembers(msg.to, nm15)
                                   for x in range (300, len(nama)-1):
                                       nm16 += [nama[x]]
                                   mentionMembers(msg.to, nm16)

                        elif cmd == "listbot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +noobcoder.getContact(m_id).displayName + "\n"
                                noobcoder.sendMessage(msg.to,"Eric Bots\n\n"+ma+"\nTotal「%s」 Bots" %(str(len(Bots))))

                        elif cmd == ".admins":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                a = 0
                                b = 0
                                c = 0
                                for m_id in owner:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +noobcoder.getContact(m_id).displayName + "\n"
                                for m_id in admin:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +noobcoder.getContact(m_id).displayName + "\n"
                                for m_id in staff:
                                    c = c + 1
                                    end = '\n'
                                    mc += str(c) + ". " +noobcoder.getContact(m_id).displayName + "\n"
                                noobcoder.sendMessage(msg.to,"Admin list \n\nSuper admin:\n"+ma+"\nAdmin:\n"+mb+"\nStaff:\n"+mc+"\nTotal「%s」" %(str(len(owner)+len(admin)+len(staff))))

                        elif cmd == ".listprotect":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ma = ""
                                mb = ""
                                mc = ""
                                md = ""
                                me = ""
                                mf = ""
                                a = 0
                                gid = protectqr
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +noobcoder.getGroup(group).name + "\n"
                                gid = protectkick
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mb += str(a) + ". " +noobcoder.getGroup(group).name + "\n"
                                gid = protectjoin
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    md += str(a) + ". " +noobcoder.getGroup(group).name + "\n"
                                gid = protectcancel
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mc += str(a) + ". " +noobcoder.getGroup(group).name + "\n"
                                gid = protectinvite
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    me += str(a) + ". " +noobcoder.getGroup(group).name + "\n"
                                gid = protectantijs
                                for group in gid:
                                    a = a + 1
                                    end = '\n'
                                    mf += str(a) + ". " +noobcoder.getGroup(group).name + "\n"
                                noobcoder.sendMessage(msg.to,"「◄━━◈⟦Eric_Protection⟧◈━━►」\n\n「✭」 PROTECT URL :\n"+ma+"\n「✭」 PROTECT KICK :\n"+mb+"\n「✭」 PROTECT JOIN :\n"+md+"\n「✭」 PROTECT CANCEL:\n"+mc+"\n「✭」 PROTECT INVITE:\n"+me+"\n「✭」 PROTECT ANTIJS :\n"+mf+"\nTotal「%s」Grous" %(str(len(protectqr)+len(protectkick)+len(protectjoin)+len(protectcancel)+len(protectinvite)+len(protectantijs))))

                        elif cmd == "respon":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                ki.sendMessage(msg.to,responsename1)
                                kk.sendMessage(msg.to,responsename2)
                                kc.sendMessage(msg.to,responsename3)
                                km.sendMessage(msg.to,responsename4)
                                kb.sendMessage(msg.to,responsename5)
                                kn.sendMessage(msg.to,responsename6)
                                ko.sendMessage(msg.to,responsename7)
                                kw.sendMessage(msg.to,responsename8)
                                ke.sendMessage(msg.to,responsename9)
                                ky.sendMessage(msg.to,responsename10)
                                
                        elif cmd == "invitebot":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    anggota = [Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid,Zmid,JSmid]
                                    noobcoder.inviteIntoGroup(msg.to, anggota)
                                    ki.acceptGroupInvitation(msg.to)
                                    kk.acceptGroupInvitation(msg.to)
                                    kc.acceptGroupInvitation(msg.to)
                                    km.acceptGroupInvitation(msg.to)
                                    kb.acceptGroupInvitation(msg.to)
                                    kn.acceptGroupInvitation(msg.to)
                                    ko.acceptGroupInvitation(msg.to)
                                    kw.acceptGroupInvitation(msg.to)
                                    ke.acceptGroupInvitation(msg.to)
                                    ky.acceptGroupInvitation(msg.to)
                                except:
                                    pass
                                
                        elif cmd == ".stay":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                try:
                                    ginfo = noobcoder.getGroup(msg.to)
                                    noobcoder.inviteIntoGroup(msg.to, [JSmid])
                                    noobcoder.sendMessage(msg.to,"Grup 「"+str(ginfo.name)+"」 Staying JS")
                                except:
                                    pass
    
                        elif cmd == ".in":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                km.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kn.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ko.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ky.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ky.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ky.updateGroup(G)

                        elif cmd == ".out":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ki.sendText(msg.to, "Bye bye "+str(G.name))
                                ki.leaveGroup(msg.to)
                                kk.leaveGroup(msg.to)
                                kc.leaveGroup(msg.to)
                                km.leaveGroup(msg.to)
                                kb.leaveGroup(msg.to)
                                kn.leaveGroup(msg.to)
                                ko.leaveGroup(msg.to)
                                kw.leaveGroup(msg.to)
                                ke.leaveGroup(msg.to)
                                ky.leaveGroup(msg.to)
                                
                        elif cmd == ".bye":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                noobcoder.sendText(msg.to, "Bye bye "+str(G.name))
                                noobcoder.leaveGroup(msg.to)

                        elif cmd.startswith("leave "):
                            if msg._from in admin:
                                proses = text.split(" ")
                                ng = text.replace(proses[0] + " ","")
                                gid = noobcoder.getGroupIdsJoined()
                                for i in gid:
                                    h = noobcoder.getGroup(i).name
                                    if h == ng:
                                        ki.sendMessage(i, "Silahkan admin invite atau masukan kembali")
                                        ki.leaveGroup(i)
                                        kk.leaveGroup(i)
                                        kc.leaveGroup(i)
                                        km.leaveGroup(i)
                                        kb.leaveGroup(i)
                                        kn.leaveGroup(i)
                                        ko.leaveGroup(i)
                                        kw.leaveGroup(i)
                                        ke.leaveGroup(i)
                                        ky.leaveGroup(i)
                                        noobcoder.sendMessage(to,"Berhasil keluar dari grup " +h)

                        elif cmd == "assist1":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ki.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ki.updateGroup(G)

                        elif cmd == "assist2":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kk.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kk.updateGroup(G)

                        elif cmd == "assist3":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kc.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kc.updateGroup(G)
                                
                        elif cmd == "assist4":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                km.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = km.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                km.updateGroup(G)

                        elif cmd == "assist5":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kb.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kb.updateGroup(G)

                        elif cmd == "assist6":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                kn.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kn.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kn.updateGroup(G)
                                
                        elif cmd == "assist7":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                ko.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ko.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ko.updateGroup(G)

                        elif cmd == "assist8":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                kw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = kw.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                kw.updateGroup(G)

                        elif cmd == "assist9":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ke.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ke.updateGroup(G)
                                
                        elif cmd == "assist10":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                ky.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = ky.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                ky.updateGroup(G)

                        elif cmd == ".ghost join":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                ginfo = noobcoder.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                noobcoder.updateGroup(G)
                                invsend = 0
                                Ticket = noobcoder.reissueGroupTicket(msg.to)
                                sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                sx.acceptGroupInvitationByTicket(msg.to,Ticket)
                                js.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = js.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                js.updateGroup(G)

                        elif cmd == ".ghost bye":
                            if msg._from in admin:
                                G = noobcoder.getGroup(msg.to)
                                sw.leaveGroup(msg.to)
                                sx.leaveGroup(msg.to)
                                js.leaveGroup(msg.to)

                        elif cmd == "!sp":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                get_profile_time_start = time.time()
                                get_profile = noobcoder.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = noobcoder.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = noobcoder.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                #noobcoder.sendMessage(msg.to, "Speed respon\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))
                                noobcoder.sendFooter(msg.to,"Speed respon\n\n - Get Profile\n   %.10f\n - Get Contact\n   %.10f\n - Get Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))
                        elif cmd == "speed" or cmd == "sp":
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               start = time.time()
                               noobcoder.sendMessage(msg.to, "speed is...")
                               elapsed_time = time.time() - start
                               noobcoder.sendMessage(msg.to, "{} seconds".format(str(elapsed_time)))

                        elif cmd == "lurking on":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Setmain['ARreadPoint'][msg.to] = msg_id
                                 Setmain['ARreadMember'][msg.to] = {}
                                 noobcoder.sendText(msg.to, "Lurking berhasil diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurking off":
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Setmain['ARreadPoint'][msg.to]
                                 del Setmain['ARreadMember'][msg.to]
                                 noobcoder.sendText(msg.to, "Lurking berhasil dinoaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                            
                        elif cmd == "lurkers":
                          if msg._from in admin:
                            if msg.to in Setmain['ARreadPoint']:
                                if Setmain['ARreadMember'][msg.to] != {}:
                                    aa = []
                                    for x in Setmain['ARreadMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n\n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(noobcoder.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        noobcoder.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Setmain['ARreadPoint'][msg.to]
                                        del Setmain['ARreadMember'][msg.to]
                                    except:
                                        pass
                                    Setmain['ARreadPoint'][msg.to] = msg.id
                                    Setmain['ARreadMember'][msg.to] = {}
                                else:
                                    noobcoder.sendText(msg.to, "User kosong...")
                            else:
                                noobcoder.sendText(msg.to, "Ketik lurking on dulu")

                        elif cmd == "sider on":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  noobcoder.sendMessage(msg.to, "Cek sider diaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True

                        elif cmd == "sider off":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  noobcoder.sendMessage(msg.to, "Cek sider dinonaktifkan\n\nTanggal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                              else:
                                  noobcoder.sendMessage(msg.to, "Sudak tidak aktif")

#===========Hiburan============#
                        elif cmd.startswith("sholat: "):
                          if msg._from in admin:
                             sep = text.split(" ")
                             location = text.replace(sep[0] + " ","")
                             with requests.session() as web:
                                  web.headers["user-agent"] = random.choice(settings["userAgent"])
                                  r = web.get("http://api.corrykalam.net/apisholat.php?lokasi={}".format(urllib.parse.quote(location)))
                                  data = r.text
                                  data = json.loads(data)
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  if data[1] != "Subuh : " and data[2] != "Dzuhur : " and data[3] != "Ashar : " and data[4] != "Maghrib : " and data[5] != "Isha : ":
                                         ret_ = "「Jadwal Sholat」"
                                         ret_ += "\n❧Lokasi : " + data[0]
                                         ret_ += "\n❧" + data[1]
                                         ret_ += "\n❧" + data[2]
                                         ret_ += "\n❧" + data[3]
                                         ret_ += "\n❧" + data[4]
                                         ret_ += "\n❧" + data[5]
                                         ret_ += "\n\nTanggal : " + datetime.strftime(timeNow,'%Y-%m-%d')
                                         ret_ += "\nJam : " + datetime.strftime(timeNow,'%H:%M:%S')
                                  noobcoder.sendMessage(msg.to, str(ret_))

                        elif cmd.startswith("cuaca: "):
                          if msg._from in admin:
                            separate = text.split(" ")
                            location = text.replace(separate[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apicuaca.php?kota={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                tz = pytz.timezone("Asia/Jakarta")
                                timeNow = datetime.now(tz=tz)
                                if "result" not in data:
                                    ret_ = "「Status Cuaca」"
                                    ret_ += "\n❧Lokasi : " + data[0].replace("Temperatur di kota ","")
                                    ret_ += "\n❧Suhu : " + data[1].replace("Suhu : ","") + " C"
                                    ret_ += "\n❧Kelembaban : " + data[2].replace("Kelembaban : ","") + " %"
                                    ret_ += "\n❧Tekanan udara : " + data[3].replace("Tekanan udara : ","") + " HPa"
                                    ret_ += "\n❧Kecepatan angin : " + data[4].replace("Kecepatan angin : ","") + " m/s"
                                    ret_ += "\n\nTanggal : " + datetime.strftime(timeNow,'%Y-%m-%d')
                                    ret_ += "\nJam : " + datetime.strftime(timeNow,'%H:%M:%S')
                                noobcoder.sendMessage(msg.to, str(ret_))

                        elif cmd.startswith("lokasi: "):
                          if msg._from in admin:
                            separate = msg.text.split(" ")
                            location = msg.text.replace(separate[0] + " ","")
                            with requests.session() as web:
                                web.headers["user-agent"] = random.choice(settings["userAgent"])
                                r = web.get("http://api.corrykalam.net/apiloc.php?lokasi={}".format(urllib.parse.quote(location)))
                                data = r.text
                                data = json.loads(data)
                                if data[0] != "" and data[1] != "" and data[2] != "":
                                    link = "https://www.google.co.id/maps/@{},{},15z".format(str(data[1]), str(data[2]))
                                    ret_ = "「Info Lokasi」"
                                    ret_ += "\n❧Location : " + data[0]
                                    ret_ += "\n❧Google Maps : " + link
                                else:
                                    ret_ = "[Details Location] Error : Location not found"
                                noobcoder.sendMessage(msg.to,str(ret_))

                        elif cmd.startswith("lirik: "):
                           if msg._from in admin:
                               sep = msg.text.split(" ")
                               search = msg.text.replace(sep[0] + " ","")
                               params = {'songname': search}
                               with requests.session() as web:
                                   web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                   r = web.get("https://ide.fdlrcn.com/workspace/yumi-apis/joox?{}".format(urllib.parse.urlencode(params)))
                                   try:
                                      data = json.loads(r.text)
                                      for song in data:
                                          songs = song[5]
                                          lyric = songs.replace('ti:','Title - ')
                                          lyric = lyric.replace('ar:','Artist - ')
                                          lyric = lyric.replace('al:','Album - ')
                                          removeString = "[1234567890.:]"
                                          for char in removeString:
                                              lyric = lyric.replace(char,'')
                                          ret_ = "╔══[ Lyric ]"
                                          ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                          ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                          ret_ += "\n╠ Link : {}".format(str(song[3]))
                                          ret_ += "\n╚══[ Finish ]\n\nLirik nya :\n{}".format(str(lyric))
                                          noobcoder.sendText(msg.to, str(ret_))
                                   except:
                                       noobcoder.sendText(to, "Lirik tidak ditemukan")
                            
                        elif cmd.startswith("music: "):
                           if msg._from in admin:
                              sep = msg.text.split(" ")
                              search = msg.text.replace(sep[0] + " ","")
                              params = {'songname': search}
                              with requests.session() as web:
                                  web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                  r = web.get("https://ide.fdlrcn.com/workspace/yumi-apis/joox?{}".format(urllib.parse.urlencode(params)))
                                  try:
                                      data = json.loads(r.text)
                                      for song in data:
                                          ret_ = "╔══[ Music ]"
                                          ret_ += "\n╠ Nama lagu : {}".format(str(song[0]))
                                          ret_ += "\n╠ Durasi : {}".format(str(song[1]))
                                          ret_ += "\n╠ Link : {}".format(str(song[3]))
                                          ret_ += "\n╚══[ Waiting Audio ]"
                                      noobcoder.sendText(msg.to, str(ret_))
                                      noobcoder.sendText(msg.to, "Mohon bersabar musicnya lagi di upload")
                                      noobcoder.sendAudioWithURL(msg.to, song[3])
                                  except:
                                      noobcoder.sendText(to, "Musik tidak ditemukan")

                        elif cmd.startswith("gimage: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            search = msg.text.replace(sep[0] + " ","")
                            url = "https://api.xeonwz.ga/api/image/google?q={}".format(urllib.parse.quote(search))
                            with requests.session() as web:
                                web.headers["User-Agent"] = random.choice(settings["userAgent"])
                                r = web.get(url)
                                data = r.text
                                data = json.loads(data)
                                if data["data"] != []:
                                    start = timeit.timeit()
                                    items = data["data"]
                                    path = random.choice(items)
                                    a = items.index(path)
                                    b = len(items)
                                    noobcoder.sendText(msg.to,"「Google Image」\nType : Search Image\nTime taken : %seconds" % (start))
                                    noobcoder.sendImageWithURL(msg.to, str(path))

                        elif cmd.startswith("ytmp4: "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    me = best.url
                                    hasil = ""
                                    title = "Judul [ " + vid.title + " ]"
                                    author = '\n\n❧Author : ' + str(vid.author)
                                    durasi = '\n❧Duration : ' + str(vid.duration)
                                    suka = '\n❧Likes : ' + str(vid.likes)
                                    rating = '\n❧Rating : ' + str(vid.rating)
                                    deskripsi = '\n❧Deskripsi : ' + str(vid.description)
                                noobcoder.sendVideoWithURL(msg.to, me)
                                noobcoder.sendText(msg.to,title+ author+ durasi+ suka+ rating+ deskripsi)
                            except Exception as e:
                                noobcoder.sendText(msg.to,str(e))

                        elif cmd.startswith("ytmp3: "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                textToSearch = msg.text.replace(sep[0] + " ","")
                                query = urllib.parse.quote(textToSearch)
                                search_url="https://www.youtube.com/results?search_query="
                                mozhdr = {'User-Agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'}
                                sb_url = search_url + query
                                sb_get = requests.get(sb_url, headers = mozhdr)
                                soupeddata = BeautifulSoup(sb_get.content, "html.parser")
                                yt_links = soupeddata.find_all("a", class_ = "yt-uix-tile-link")
                                x = (yt_links[1])
                                yt_href =  x.get("href")
                                yt_href = yt_href.replace("watch?v=", "")
                                qx = "https://youtu.be" + str(yt_href)
                                vid = pafy.new(qx)
                                stream = vid.streams
                                bestaudio = vid.getbestaudio()
                                bestaudio.bitrate
                                best = vid.getbest()
                                best.resolution, best.extension
                                for s in stream:
                                    shi = bestaudio.url
                                    me = best.url
                                    vin = s.url
                                    hasil = ""
                                    title = "Judul [ " + vid.title + " ]"
                                    author = '\n\n❧Author : ' + str(vid.author)
                                    durasi = '\n❧Duration : ' + str(vid.duration)
                                    suka = '\n❧Likes : ' + str(vid.likes)
                                    rating = '\n❧Rating : ' + str(vid.rating)
                                    deskripsi = '\n❧Deskripsi : ' + str(vid.description)
                                noobcoder.sendImageWithURL(msg.to, me)
                                noobcoder.sendAudioWithURL(msg.to, shi)
                                noobcoder.sendText(msg.to,title+ author+ durasi+ suka+ rating+ deskripsi)
                            except Exception as e:
                                noobcoder.sendText(msg.to,str(e))

                        elif cmd.startswith("profileig: "):
                          if msg._from in admin:
                            try:
                                sep = msg.text.split(" ")
                                instagram = msg.text.replace(sep[0] + " ","")
                                response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                                data = response.json()
                                namaIG = str(data['user']['full_name'])
                                bioIG = str(data['user']['biography'])
                                mediaIG = str(data['user']['media']['count'])
                                verifIG = str(data['user']['is_verified'])
                                usernameIG = str(data['user']['username'])
                                followerIG = str(data['user']['followed_by']['count'])
                                profileIG = data['user']['profile_pic_url_hd']
                                privateIG = str(data['user']['is_private'])
                                followIG = str(data['user']['follows']['count'])
                                link = "❧Link : " + "https://www.instagram.com/" + instagram
                                text = "❧Name : "+namaIG+"\n❧Username : "+usernameIG+"\n❧Biography : "+bioIG+"\n❧Follower : "+followerIG+"\n❧Following : "+followIG+"\n❧Post : "+mediaIG+"\n❧Verified : "+verifIG+"\n❧Private : "+privateIG+"" "\n" + link
                                noobcoder.sendImageWithURL(msg.to, profileIG)
                                noobcoder.sendMessage(msg.to, str(text))
                            except Exception as e:
                                    noobcoder.sendMessage(msg.to, str(e))

                        elif cmd.startswith("cekdate: "):
                          if msg._from in admin:
                            sep = msg.text.split(" ")
                            tanggal = msg.text.replace(sep[0] + " ","")
                            r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tanggal='+tanggal)
                            data=r.text
                            data=json.loads(data)
                            lahir = data["data"]["lahir"]
                            usia = data["data"]["usia"]
                            ultah = data["data"]["ultah"]
                            zodiak = data["data"]["zodiak"]
                            noobcoder.sendMessage(msg.to,"❧I N F O R M A S I ❧\n\n"+"❧Date Of Birth : "+lahir+"\n❧Age : "+usia+"\n❧Ultah : "+ultah+"\n❧Zodiak : "+zodiak)

                        elif cmd.startswith("jumlah: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Setmain["ARlimit"] = num
                                noobcoder.sendText(msg.to,"Total Spamtag Diubah Menjadi " +strnum)

                        elif cmd.startswith("spamcall: "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                wait["limit"] = num
                                noobcoder.sendText(msg.to,"Total Spamcall " +strnum)

                        elif cmd.startswith("spamtag "):
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Setmain["ARlimit"])
                                    if jmlh <= 1000:
                                        for x in range(jmlh):
                                            try:
                                                noobcoder.sendMessage1(msg)
                                            except Exception as e:
                                                noobcoder.sendText(msg.to,str(e))
                                    else:
                                        noobcoder.sendText(msg.to,"total 1000")
                                        
                        elif cmd == "spamcall":
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                             if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(wait["limit"])
                                noobcoder.sendMessage(msg.to, "DOne {} Spam Call Grup".format(str(wait["limit"])))
                                if jmlh <= 1000:
                                  for x in range(jmlh):
                                     try:
                                        call.acquireGroupCallRoute(to)
                                        call.inviteIntoGroupCall(to, contactIds=members)
                                     except Exception as e:
                                        noobcoder.sendText(msg.to,str(e))
                                else:
                                    noobcoder.sendText(msg.to,"Jumlah melebihi batas")

                        elif 'Gift: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      noobcoder.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                      ki.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                      kk.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                                      kc.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)

                        elif 'Spam: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in range(0,jumlah):
                                      noobcoder.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      ki.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kk.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kc.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      km.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kb.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      kn.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      ko.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      cw.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      ke.sendMessage(midd, str(Setmain["ARmessage1"]))
                                      ky.sendMessage(midd, str(Setmain["ARmessage1"]))

                        elif 'ID line: ' in msg.text:
                          if wait["selfbot"] == True:
                           if msg._from in admin:
                              msgs = msg.text.replace('ID line: ','')
                              conn = noobcoder.findContactsByUserid(msgs)
                              if True:
                                  noobcoder.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)

#===========Protection============#
                        elif 'Welcome ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in welcome:
                                       msgs = "Welcome Msg Turn On"
                                  else:
                                       welcome.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Welcome Msg Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in welcome:
                                         welcome.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Welcome Msg Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Welcome Msg Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)

                        elif 'Protecturl ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protecturl ','')
                              if spl == 'on':
                                  if msg.to in protectqr:
                                       msgs = "Protect url Turn On"
                                  else:
                                       protectqr.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Protect url Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Protect url Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)

                        elif 'Protectkick ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectkick ','')
                              if spl == 'on':
                                  if msg.to in protectkick:
                                       msgs = "Protect kick Turn On"
                                  else:
                                       protectkick.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Protect kick Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Protect kick Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect kick Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)
                        elif 'Protectinvite ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectinvite ','')
                              if spl == 'on':
                                  if msg.to in protectinvite:
                                       msgs = "Protect invite Turn On"
                                  else:
                                       protectinvite.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Protect invite Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Protect invite Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect invite Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)           

                        elif 'Protectjoin ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectjoin ','')
                              if spl == 'on':
                                  if msg.to in protectjoin:
                                       msgs = "Protect join Turn On"
                                  else:
                                       protectjoin.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Protect join Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectjoin:
                                         protectjoin.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Protect join Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect join Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)

                        elif 'Protectcancel ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Protectcancel ','')
                              if spl == 'on':
                                  if msg.to in protectcancel:
                                       msgs = "Protect cancel Turn On"
                                  else:
                                       protectcancel.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Protect cancel Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Protect cancel Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect cancel Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)

                        elif 'Antijs ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Antijs ','')
                              if spl == 'on':
                                  if msg.to in protectantijs:
                                       msgs = "Anti JS Turn On"
                                  else:
                                       protectantijs.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Anti JS Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Anti JS Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Anti JS Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)
                                    
                        elif 'Ghost ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Ghost ','')
                              if spl == 'on':
                                  if msg.to in ghost:
                                       msgs = "Ghost Turn On"
                                  else:
                                       ghost.append(msg.to)
                                       ginfo = noobcoder.getGroup(msg.to)
                                       msgs = "Ghost Turn On\nIN Group : " +str(ginfo.name)
                                  noobcoder.sendMessage(msg.to, "ON\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in ghost:
                                         ghost.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Ghost Turn off \nIn Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Ghost Turn off "
                                    noobcoder.sendMessage(msg.to, "Turn off \n" + msgs)                                    

                        elif '.max ' in msg.text:
                           if msg._from in admin:                             
                              spl = msg.text.replace('.max ','')
                              if spl == 'on':
                                #if wait["allprotect"] == True:
                                  if msg.to in protectqr:
                                       msgs = ""
                                  else:
                                       protectqr.append(msg.to)
                                  if msg.to in protectkick:
                                      msgs = ""
                                  else:
                                      protectkick.append(msg.to)
                                  if msg.to in protectinvite:
                                      msgs = ""
                                  else:
                                      protectinvite.append(msg.to)
                                  if msg.to in protectantijs:
                                      msgs = ""
                                  else:
                                      protectantijs.append(msg.to)
                                  if msg.to in ghost:
                                      msgs = ""
                                  else:
                                      ghost.append(msg.to)                                      
                                  if msg.to in protectcancel:
                                      ginfo = noobcoder.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nIN Group : " +str(ginfo.name)
                                      msgs += "\nMax protect is On"
                                  else:
                                      protectcancel.append(msg.to)
                                      ginfo = noobcoder.getGroup(msg.to)
                                      msgs = "Status : [ ON ]\nIn Group : " +str(ginfo.name)
                                      msgs += "\nMax protect Was On"
                                  noobcoder.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)
                              elif spl == 'off':
                                 #if wait["allprotect"] == False:
                                    if msg.to in protectqr:
                                         protectqr.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectkick:
                                         protectkick.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectinvite:
                                         protectinvite.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectantijs:
                                         protectantijs.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in ghost:
                                         ghost.remove(msg.to)
                                    else:
                                         msgs = ""
                                    if msg.to in protectcancel:
                                         protectcancel.remove(msg.to)
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nIn Group : " +str(ginfo.name)
                                         msgs += "\nMax protect OFF"
                                    else:
                                         ginfo = noobcoder.getGroup(msg.to)
                                         msgs = "Status : [ OFF ]\nIn Group : " +str(ginfo.name)
                                         msgs += "\nMax protect Off"
                                    noobcoder.sendMessage(msg.to, "「 Status Protection 」\n" + msgs)

#===========KICKOUT============#
                        elif ("Nk " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           G = noobcoder.getGroup(msg.to)
                                           G.preventedJoinByTicket = False
                                           noobcoder.updateGroup(G)
                                           invsend = 0
                                           Ticket = noobcoder.reissueGroupTicket(msg.to)
                                           sw.acceptGroupInvitationByTicket(msg.to,Ticket)
                                           sw.kickoutFromGroup(msg.to, [target])
                                           sw.leaveGroup(msg.to)
                                           X = noobcoder.getGroup(msg.to)
                                           X.preventedJoinByTicket = True
                                           noobcoder.updateGroup(X)
                                       except:
                                           pass

                        elif ("اذلف " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           noobcoder.sendFooter(msg.to,"اذلف اذلف")
                                           random.choice(ABC).kickoutFromGroup(msg.to, [target])
                                       except:
                                           pass

                        elif (" كلزق" in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = [contact.mid for contact in group.members]
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Bots:
                                       try:
                                           noobcoder.sendFooter(msg.to,"يرا يرا")
                                           random.choice(ABC).kickoutFromGroup(msg.to, [targets])
                                       except:
                                           pass

#===========ADMIN ADD============#
                        elif (".Adminadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           admin.append(target)
                                           noobcoder.sendFooter(msg.to,"Done Add admin")
                                       except:
                                           pass

                        elif ("Staffadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in owner:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           staff.append(target)
                                           noobcoder.sendMessage(msg.to,"Done Adding staff")
                                       except:
                                           pass

                        elif ("Botadd " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           Bots.append(target)
                                           noobcoder.sendMessage(msg.to,"Done Adding bot")
                                       except:
                                           pass

                        elif (".admindell " in msg.text):
                            if msg._from in owner:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Dpk:
                                       try:
                                           admin.remove(target)
                                           noobcoder.sendMessage(msg.to,"Done Delling admin")
                                       except:
                                           pass

                        elif (".staffdell " in msg.text):
                            if msg._from in owner:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Dpk:
                                       try:
                                           staff.remove(target)
                                           noobcoder.sendMessage(msg.to,"Done Delling admin")
                                       except:
                                           pass

                        elif (".botdell " in msg.text):
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Dpk:
                                       try:
                                           Bots.remove(target)
                                           noobcoder.sendMessage(msg.to,"Done Delling admin")
                                       except:
                                           pass

                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if msg._from in admin:
                                wait["addadmin"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "admin:repeat" or text.lower() == 'admin:repeat':
                            if msg._from in admin:
                                wait["delladmin"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "staff:on" or text.lower() == 'staff:on':
                            if msg._from in admin:
                                wait["addstaff"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "staff:repeat" or text.lower() == 'staff:repeat':
                            if msg._from in admin:
                                wait["dellstaff"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if msg._from in admin:
                                wait["addbots"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "bot:repeat" or text.lower() == 'bot:repeat':
                            if msg._from in admin:
                                wait["dellbots"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == ".refresh" or text.lower() == 'refresh':
                            if msg._from in admin:
                                wait["addadmin"] = False
                                wait["delladmin"] = False
                                wait["addstaff"] = False
                                wait["dellstaff"] = False
                                wait["addbots"] = False
                                wait["dellbots"] = False
                                wait["wblacklist"] = False
                                wait["dblacklist"] = False
                                wait["Talkwblacklist"] = False
                                wait["Talkdblacklist"] = False
                                noobcoder.sendText(msg.to,"Done Refresh...")

                        elif cmd == "contact admin" or text.lower() == 'contact admin':
                            if msg._from in admin:
                                ma = ""
                                for i in admin:
                                    ma = noobcoder.getContact(i)
                                    noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact staff" or text.lower() == 'contact staff':
                            if msg._from in admin:
                                ma = ""
                                for i in staff:
                                    ma = noobcoder.getContact(i)
                                    noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == "contact bot" or text.lower() == 'contact bot':
                            if msg._from in admin:
                                ma = ""
                                for i in Bots:
                                    ma = noobcoder.getContact(i)
                                    noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

#===========COMMAND ON OFF============#
                        elif cmd == "notag on" or text.lower() == 'notag on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Mentionkick"] = True
                                noobcoder.sendText(msg.to,"Notag diaktifkan")

                        elif cmd == "notag off" or text.lower() == 'notag off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["MentionKick"] = False
                                noobcoder.sendText(msg.to,"Notag dinonaktifkan")

                        elif cmd == "contact on" or text.lower() == 'contact on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = True
                                noobcoder.sendText(msg.to,"Deteksi contact diaktifkan")

                        elif cmd == "contact off" or text.lower() == 'contact off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["contact"] = False
                                noobcoder.sendText(msg.to,"Deteksi contact dinonaktifkan")

                        elif cmd == ".nuke on" or text.lower() == 'اغتصاب؟':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["InCiak"] = True
                                noobcoder.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                ki.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                kc.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                kb.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                kk.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                km.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                kn.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                kb.sendText(msg.to,"بنعرس مين؟؟؟؟")
                                ke.sendText(msg.to,"بنعرس مين؟؟؟؟")

                        elif cmd == ".nuke off" or text.lower() == 'خلاص':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["InCiak"] = False
                                noobcoder.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                ki.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                kc.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                kb.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                kk.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                km.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                kn.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                kb.sendText(msg.to,"زغبناهم بنرتاح شوي!!")
                                ke.sendText(msg.to,"زغبناهم بنرتاح شوي!!")

                        elif cmd == "autojoin on" or text.lower() == 'autojoin on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = True
                                data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello , {}".format(user),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "Auto Join On",
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                            "action": {
                                "type": "uri",
                                "uri": "{}".format(link)
                            }
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                                     sendTemplate(to, data)
                        elif cmd == "autojoin off" or text.lower() == 'autojoin off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoin"] = False
                                noobcoder.sendText(msg.to,"Autojoin dinonaktifkan")

                        elif cmd == "autoleave on" or text.lower() == 'autoleave on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = True
                                noobcoder.sendText(msg.to,"Autoleave diaktifkan")

                        elif cmd == "autoleave off" or text.lower() == 'autoleave off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoLeave"] = False
                                noobcoder.sendText(msg.to,"Autoleave dinonaktifkan")

                        elif cmd == "autoadd on" or text.lower() == 'autoadd on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = True
                                noobcoder.sendText(msg.to,"Auto add diaktifkan")

                        elif cmd == "autoadd off" or text.lower() == 'autoadd off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoAdd"] = False
                                noobcoder.sendText(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "read on" or text.lower() == 'autoread on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = True
                                noobcoder.sendText(msg.to,"Auto add diaktifkan")

                        elif cmd == "read off" or text.lower() == 'autoread off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoRead"] = False
                                noobcoder.sendText(msg.to,"Auto add dinonaktifkan")

                        elif cmd == "sticker on" or text.lower() == 'sticker on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = True
                                noobcoder.sendText(msg.to,"Deteksi sticker diaktifkan")

                        elif cmd == "sticker off" or text.lower() == 'sticker off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["sticker"] = False
                                noobcoder.sendText(msg.to,"Deteksi sticker dinonaktifkan")

                        elif cmd == "jointicket on" or text.lower() == 'jointicket on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = True
                                noobcoder.sendText(msg.to,"Join ticket diaktifkan")

                        elif cmd == "jointicket off" or text.lower() == 'jointicket off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["autoJoinTicket"] = False
                                noobcoder.sendText(msg.to,"Autojoin Tiket dinonaktifkan")

#===========COMMAND BLACKLIST============#
                        elif ("Talkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["Talkblacklist"][target] = True
                                           noobcoder.sendMessage(msg.to,"Done Adding blacklist")
                                       except:
                                           pass

                        elif ("Untalkban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["Talkblacklist"][target]
                                           noobcoder.sendMessage(msg.to,"Done Delling blacklist")
                                       except:
                                           pass

                        elif cmd == "talkban:on" or text.lower() == 'talkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkwblacklist"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "untalkban:on" or text.lower() == 'untalkban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["Talkdblacklist"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif ("Ban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           wait["blacklist"][target] = True
                                           noobcoder.sendMessage(msg.to,"Done Adding blacklist")
                                       except:
                                           pass

                        elif ("Unban " in msg.text):
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                       try:
                                           del wait["blacklist"][target]
                                           noobcoder.sendMessage(msg.to,"Done Delling blacklist")
                                       except:
                                           pass

                        elif cmd == "ban:on" or text.lower() == 'ban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["wblacklist"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "unban:on" or text.lower() == 'unban:on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["dblacklist"] = True
                                noobcoder.sendText(msg.to,"Send Contact...")

                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                noobcoder.sendMessage(msg.to,"Noting blacklist")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +noobcoder.getContact(m_id).displayName + "\n"
                                noobcoder.sendMessage(msg.to,"Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(wait["blacklist"]))))

                        elif cmd == "talkbanlist" or text.lower() == 'talkbanlist':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["Talkblacklist"] == {}:
                                noobcoder.sendMessage(msg.to,"Tidak ada Talkban user")
                              else:
                                ma = ""
                                a = 0
                                for m_id in wait["Talkblacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +noobcoder.getContact(m_id).displayName + "\n"
                                noobcoder.sendMessage(msg.to,"Famz__Botz Talkban User\n\n"+ma+"\nTotal「%s」Talkban User" %(str(len(wait["Talkblacklist"]))))

                        elif cmd == ".blc" or text.lower() == 'blc':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              if wait["blacklist"] == {}:
                                    noobcoder.sendMessage(msg.to,"Noting in blacklist")
									ki.sendText(msg.to,"Noting in blacklist")
                                    kc.sendText(msg.to,"Noting in blacklist")
                                    kb.sendText(msg.to,"Noting in blacklist")
                                    kk.sendText(msg.to,"Noting in blacklist")
                                    km.sendText(msg.to,"Noting in blacklist")
                                    kn.sendText(msg.to,"Noting in blacklist")
                                    kb.sendText(msg.to,"Noting in blacklist")
                                    ke.sendText(msg.to,"Noting in blacklist")
                              else:
                                    ma = ""
                                    for i in wait["blacklist"]:
                                        ma = noobcoder.getContact(i)
                                        noobcoder.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)

                        elif cmd == ".cban" or text.lower() == '.clearban':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                              wait["blacklist"] = {}
                              ragets = noobcoder.getContacts(wait["blacklist"])
                              mc = "「%i」User Blacklist" % len(ragets)
                              noobcoder.sendMessage(msg.to,"Done clear Black list " +mc)
									ki.sendText(msg.to,"Done clear Black list " +mc)
                                    kc.sendText(msg.to,"Done clear Black list " +mc)
                                    kb.sendText(msg.to,"Done clear Black list " +mc)
                                    kk.sendText(msg.to,"Done clear Black list " +mc)
                                    km.sendText(msg.to,"Done clear Black list " +mc)
                                    kn.sendText(msg.to,"Done clear Black list " +mc)
                                    kb.sendText(msg.to,"Done clear Black list " +mc)
                                    ke.sendText(msg.to,"Done clear Black list " +mc)
#===========COMMAND SET============#
                        elif 'Set pesan: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set pesan: ','')
                              if spl in [""," ","\n",None]:
                                  noobcoder.sendMessage(msg.to, "Gagal mengganti Pesan Msg")
                              else:
                                  wait["message"] = spl
                                  noobcoder.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set welcome: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set welcome: ','')
                              if spl in [""," ","\n",None]:
                                  noobcoder.sendMessage(msg.to, "Welcome Msg")
                              else:
                                  wait["welcome"] = spl
                                  noobcoder.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg :\n\n「{}」".format(str(spl)))

                        elif 'Set respon: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set respon: ','')
                              if spl in [""," ","\n",None]:
                                  noobcoder.sendMessage(msg.to, "Gagal mengganti Respon Msg")
                              else:
                                  wait["Respontag"] = spl
                                  noobcoder.sendMessage(msg.to, "「Respon Msg」\nRespon Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set spam: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set spam: ','')
                              if spl in [""," ","\n",None]:
                                  noobcoder.sendMessage(msg.to, "Gagal mengganti Spam")
                              else:
                                  Setmain["ARmessage1"] = spl
                                  noobcoder.sendMessage(msg.to, "「Spam Msg」\nSpam Msg diganti jadi :\n\n「{}」".format(str(spl)))

                        elif 'Set sider: ' in msg.text:
                           if msg._from in admin:
                              spl = msg.text.replace('Set sider: ','')
                              if spl in [""," ","\n",None]:
                                  noobcoder.sendMessage(msg.to, "Sider Msg:")
                              else:
                                  wait["mention"] = spl
                                  noobcoder.sendMessage(msg.to, "「Sider Msg」\nSider Msg :\n\n「{}」".format(str(spl)))

                        elif text.lower() == "cek pesan":
                            if msg._from in admin:
                               noobcoder.sendMessage(msg.to, "「Pesan Msg」\nPesan Msg mu :\n\n「 " + str(wait["message"]) + " 」")

                        elif text.lower() == "cek welcome":
                            if msg._from in admin:
                               noobcoder.sendMessage(msg.to, "「Welcome Msg」\nWelcome Msg mu :\n\n「 " + str(wait["welcome"]) + " 」")

                        elif text.lower() == "cek respon":
                            if msg._from in admin:
                               noobcoder.sendMessage(msg.to, "「Respon Msg」\nRespon Msg mu :\n\n「 " + str(wait["Respontag"]) + " 」")

                        elif text.lower() == "cek spam":
                            if msg._from in admin:
                               noobcoder.sendMessage(msg.to, "「Spam Msg」\nSpam Msg mu :\n\n「 " + str(Setmain["ARmessage1"]) + " 」")

                        elif text.lower() == "cek sider":
                            if msg._from in admin:
                               noobcoder.sendMessage(msg.to, "「Sider Msg」\nSider Msg mu :\n\n「 " + str(wait["mention"]) + " 」")

#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if wait["selfbot"] == True:
                              if settings["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = noobcoder.findGroupByTicket(ticket_id)
                                     noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     noobcoder.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group1 = ki.findGroupByTicket(ticket_id)
                                     ki.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                     ki.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group2 = kk.findGroupByTicket(ticket_id)
                                     kk.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                     kk.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group3 = kc.findGroupByTicket(ticket_id)
                                     kc.acceptGroupInvitationByTicket(group3.id,ticket_id)
                                     kc.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group4 = km.findGroupByTicket(ticket_id)
                                     km.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     km.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group5 = kb.findGroupByTicket(ticket_id)
                                     kb.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                     kb.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group6 = kn.findGroupByTicket(ticket_id)
                                     kn.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                     kn.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group7 = ko.findGroupByTicket(ticket_id)
                                     ko.acceptGroupInvitationByTicket(group3.id,ticket_id)
                                     ko.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group8 = kw.findGroupByTicket(ticket_id)
                                     kw.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     kw.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group9 = ke.findGroupByTicket(ticket_id)
                                     ke.acceptGroupInvitationByTicket(group1.id,ticket_id)
                                     ke.sendMessage(msg.to, "Done join bro : %s" % str(group.name))
                                     group10 = ky.findGroupByTicket(ticket_id)
                                     ky.acceptGroupInvitationByTicket(group2.id,ticket_id)
                                     ky.sendMessage(msg.to, "Done join bro : %s" % str(group.name))

    except Exception as error:
        print (error)


while True:
    try:
        ops = poll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                poll.setRevision(op.revision)
                thread1 = threading.Thread(target=bot, args=(op,))#self.OpInterrupt[op.type], args=(op,)
                thread1.start()
                thread1.join()
    except Exception as e:
        pass
#=====================================================================
async def noobcoderBot(op):
    try:
        if settings["restartPoint"] != None:
            noobcoder.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return
                        
        if op.type in [22,24]:
            client.leaveRoom(op.param1)
#=====================================================================
        if op.type == 13:
            if noobcoder.getProfile().mid in op.param3:
                G = noobcoder.getCompactGroup(op.param1)
                if settings["autoJoin"] == True:
                    noobcoder.acceptGroupInvitation(op.param1)
        if op.type == 15:
            print ("[ 15 ] NOTIFIED LEAVE GROUP")
            if lvin["lMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = lvin["textnya"]
                data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Bye bye {}".format(str(mat.displayName)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesanya),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                sendTemplate(op.param1,data)
        if op.type == 17:
            print ("[ 17 ] NOTIFIED INVITE INTO GROUP")
            if wmin["wMessage"] == True:
                mat = noobcoder.getContact(op.param2)
                fit = noobcoder.getCompactGroup(op.param1)
                pesanya = wmin["textnya"]
                data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(mat.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello {}".format(str(mat.displayName)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "Welcome to {}".format(str(fit.name)),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesanya),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                sendTemplate(op.param1,data)
        if op.type == 19:
                    khie = noobcoder.getContact(op.param2)
                    ayu = noobcoder.getContact(op.param3)
                    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "#ffffff",
    "contents": [
      {
        "type": "text",
        "text": "KICK NOTIFY",
        "weight": "bold",
        "size": "xxl",
        "margin": "md"
      },
      {
        "type": "separator",
        "color": "#000000"
      },
      {
        "type": "text",
        "text": "Execution :",
        "weight": "bold",
        "size": "md",
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(khie.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{noobcoder.getContact(op.param2).displayName}",
                    "size": "md",
                    "color": "#000000"
                  }
                ],
                "spacing": "md",
                "margin": "sm",
                "offsetTop": "2px"
              }
            ]
          }
        ],
        "spacing": "xl",
        "paddingAll": "6px"
      },
      {
        "type": "text",
        "text": "Victim :",
        "weight": "bold",
        "size": "md",
        "margin": "md"
      },
      {
        "type": "box",
        "layout": "horizontal",
        "contents": [
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "image",
                "url": "https://obs.line-scdn.net/{}".format(ayu.pictureStatus),
                "aspectMode": "cover",
                "size": "full"
              }
            ],
            "cornerRadius": "100px",
            "width": "30px",
            "height": "30px"
          },
          {
            "type": "box",
            "layout": "vertical",
            "contents": [
              {
                "type": "box",
                "layout": "baseline",
                "contents": [
                  {
                    "type": "text",
                    "text": f"{noobcoder.getContact(op.param3).displayName}",
                    "size": "md",
                    "color": "#000000"
                  }
                ],
                "spacing": "md",
                "margin": "sm",
                "offsetTop": "2px"
              }
            ]
          }
        ],
        "spacing": "xl",
        "paddingAll": "6px"
      }
    ],
    "paddingAll": "0px"
  }
}}
                    sendTemplate(op.param1,data)
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            khietag = "u708242457e625a5ef306804d8c0b0ac5"
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != noobcoderMID: to = sender
                else: to = receiver
                if msg.contentType == 22 and inSteals(sender):
                  if msg.toType == 0:to = sender
                  datah = {
                      "type": "flex",
                      "altText": msg.contentMetadata["ALT_TEXT"],
                      "contents": json.loads(msg.contentMetadata['FLEX_JSON'])
                  }
                  with open("kebotan", "w+") as f:
                    f.write(str(json.dumps(datah, indent=4, sort_keys=True)))
                  noobcoder.sendFile(to, "kebotan", "This ur fvcking file.txt")
                  noobcoder.sendMessage(to, "Not support html content/template, just flex!")
                if msg.contentType == 6:
                    try:
                        contact = noobcoder.getContact(sender)
                        if msg.toType == 2:
                            anu = noobcoder.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        noobcoder.sendMessage(to, str(e))
                if msg.contentType == 14:
                    if hoho["savefile"] == True:
                        try:
                             namafile = hoho["namafile"]
                             noobcoder.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             noobcoder.sendMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	noobcoder.sendMessage(to, str(e))
                if msg.contentType == 1:
                    if settings["changePicture"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id, saveAs="tmp/pict.bin")
                        settings["changePicture"] = False
                        noobcoder.updateProfilePicture(path)
                        sendFooter(to,"Profile Image Updated.")
                if msg.contentType == 1: 
                    if settings["changeCoverProfile"] == True:
                        path = noobcoder.downloadObjectMsg(msg_id)
                        settings["changeCoverProfile"] = False
                        noobcoder.updateProfileCover(path)
                        sendFooter(to,"Cover Image Updated.")                                           
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            noobcoder.sendChatChecked(to, msg_id)
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if settings["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = noobcoder.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    noobcoder.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    noobcoder.leaveGroup(group.id)
                    if msg._from in myAdmin:
                        if "/remote" in cmd:
                            function = lambda s:s[:1].lower() + s[1:] if s else ''
                            number = cmd.split("/remote:")[1];number = number.split()[0];noobcoder.getGroupIdsJoined()
                            if number.isdigit():number = int(number);group = noobcoder.getGroupIdsJoined()[number-1];to = group
                            cmd = cmd.replace("/remote:%s"%number,"").lstrip().rstrip()
                            if '/remote:' in text:text = text.replace("/remote:%s"%number,"").lstrip().rstrip();function(text)
                            else:text = text.replace("/remote:%s"%number,"").lstrip().rstrip();function(text)
                            if msg.toType == 0:msg.to = sender
                            elif msg.toType == 2:msg.to = msg.to
                            sendFooter(msg.to, "Command '%s' has been send to : %s" % (cmd, noobcoder.getGroup(group).name))
#==========================================
                    if cmd == "threads":
                        noobcoder.sendMessage(to,'Threads: {}'.format(threading.active_count()))
                        log.info("Debug Threads.")                            
#==========================================
                    elif cmd.startswith("savefile"):
                        if msg._from in myAdmin:
                            text = removeCmd("savefile", text)
                            sep = text.split(" ")
                            key = text.replace(sep[0] + " ", text)
                            if " " in key:
                                noobcoder.sendMessage(to, "Failed !")
                            else:
                                hoho["namafile"] = str(key).lower()
                                hoho["savefile"] = True
                                noobcoder.sendMessage(to, "Send file to save to be「 {} 」".format(str(key).lower()))
                    elif cmd.startswith("exec"):
                        if msg._from in myAdmin:
                            try:
                                sep = text.split("\n")
                                txt = text.replace(sep[0] + "\n","")
                                exec(txt)
                            except:
                                pass
#==========================================
                    elif cmd.startswith("down "):
                        if msg._from in myAdmin:
                           number = removeCmd("down", text)
                           if len(number) > 0:
                               if number.isdigit():
                                   number = int(number)
                                   if number > 5000:                                             
                                       noobcoder.sendMessage(to,"invalid >_< ! Max: 5000.")
                                   else:
                                       for i in range(0,number):
                                           noobcoder.sendMessage(to,str(number))
                                           number -= 1
                                           time.sleep(0.008)
                               else:
                                  noobcoder.sendMessage(to,"Please specify a valid number.")
                    elif cmd == "change dp" :
                        if msg._from in myAdmin:
                            settings["changePicture"] = True
                            sendFooter(to, "Send a Image to change picture.")
                    elif cmd == "change cover":
                        if msg._from in myAdmin:
                            settings["changeCoverProfile"] = True
                            sendFooter(to,"Send a Image to change cover.")
                    elif cmd == "read on":
                        tailah["siderTemp"][receiver] = []
                        sendFooter(to, "Getreader set to on.")
                    elif cmd == "read off":
                        if receiver in tailah["siderTemp"]:
                            del tailah["siderTemp"][receiver]
                            sendFooter(to, "Getreader set to off.")
                    elif cmd == "welcome on":
                        if wmin["wMessage"] == True:
                            msgs=" 「 Welcome 」\nWelcomemsg already Enable♪"
                        else:
                            msgs=" 「 Welcome 」\nWelcomemsg set to Enable♪"
                            wmin["wMessage"] = True
                        sendFooter(to, msgs)
                    elif cmd == "welcome off":
                        if wmin["wMessage"] == False:
                            msgs=" 「 wMessage 」\nWelcomemsg already DISABLED♪"
                        else:
                            msgs=" 「 Welcome 」\nWelcomemsg set to DISABLED♪"
                            wmin["wMessage"] = False
                        sendFooter(to, msgs)
                    elif cmd == "leave on":
                        if lvin["lMessage"] == True:
                            msgs=" 「 Leave 」\nLeavemsg already Enable♪"
                        else:
                            msgs=" 「 Leave 」\nLeavemsg set to Enable♪"
                            lvin["lMessage"] = True
                        sendFooter(to, msgs)
                    elif cmd == "leave off":
                        if lvin["lMessage"] == False:
                            msgs=" 「  Leave 」\nLeavemsg already DISABLED♪"
                        else:
                            msgs=" 「  Leave  」\nLeavemsg set to DISABLED♪"
                            lvin["lMessage"] = False
                        sendFooter(to, msgs)
                    elif cmd.startswith("updatername "):
                        if msg._from in myAdmin:
                            key = removeCmd("updatername", text)
                            kiy = settings["keyCommand"]
                            settings["keyCommand"] = str(key).lower()
                            sendFooter(to, "╭──「 Update Rname 」\n│ ⌬ Status : Success\n│ ⌬ From : "+str(kiy.title())+"\n╰To : "+str(key.title()))
                    elif cmd == "java":
                        if msg._from in myAdmin:               
                            helpz="Java code :\n" 
                            helpz+="\n• Kickall > " + str(javascript['jskick1'])
                            helpz+="\n• Bypass > " + str(javascript['jskick'])
                            helpz+="\n\nSettingsn"
                            helpz+="\n• Change 1 <txt>"
                            helpz+="\n• Change 2 <txt>"
                            noobcoder.sendMessage(to,helpz)
                    elif cmd.startswith("change"):
                        if msg._from in myAdmin:               
           #                 textx = text.replace(text.split(" ")[0]+" ","")
                            textx = removeCmd("change", text)
                            sal = textx.lower()
                            if sal.startswith("1"):
                               texts = textx[2:]
                               javascript["jskick1"] = texts
                               noobcoder.sendMessage(to, "Kickall update to `%s`" % texts)
                            if sal.startswith("2"):
                               texts = textx[2:]
                               javascript["jskick"] = texts
                               noobcoder.sendMessage(to, "Bypass update to `%s`" % texts)
                    elif cmd == javascript['jskick1']:
                        if msg._from in myAdmin:               
                          xyz = noobcoder.getGroup(to)
                          mem = [c.mid for c in xyz.members]
                          targets = []
                          for x in mem:
                            if x not in ["u6e882277271440a7c2e8a2a0a5c38cef","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targets.append(x)
                          if targets:
                            imkhie = 'simple.js gid={} token={} app={}'.format(to, noobcoder.authToken, "IOSIPAD\t11.2.5\tiPhone X\t11.2.5")
                            for target in targets:
                              imkhie += ' uid={}'.format(target)
                            success = execute_js(imkhie)
                            if success:noobcoder.sendMessage(to, "Success kick %i members." % len(targets))
                            else:noobcoder.sendMessage(to, "Failed kick %i members." % len(targets))
                          else:noobcoder.sendMessage(to, "Target not found.")
                    elif cmd == javascript['jskick']:
                        if msg._from in myAdmin: 
                          xyz = noobcoder.getGroup(to)
                          if xyz.invitee == None:pends = []
                          else:pends = [c.mid for c in xyz.invitee]
                          targp = []
                          for x in pends:
                            if x not in ["u6e882277271440a7c2e8a2a0a5c38cef","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targp.append(x)
                          mems = [c.mid for c in xyz.members]
                          targk = []
                          for x in mems:
                            if x not in ["u6e882277271440a7c2e8a2a0a5c38cef","u09c11f239846b06539d08608099f7733",noobcoder.profile.mid]:targk.append(x)
                          imkhie = 'dual.js gid={} token={}'.format(to, noobcoder.authToken)
                          for x in targp:imkhie += ' uid={}'.format(x)
                          for x in targk:imkhie += ' uik={}'.format(x)
                          execute_js(imkhie)
#==========================================
                    if cmd == "kiss me":
                        noobcoder.generateReplyMessage(msg.id)
                        noobcoder.sendReplyMessage(msg.id, to,"。。・゜゜・❤ "+noobcoder.getContact(sender).displayName+" ❤ \n(づ￣ ³￣)づ")
                    elif cmd == "reader":
                        ret = "Now set : " + str(tailah["siderPesan"])
                        ret += "\n\n⌬ {}read on/off".format(setKey)
                        ret += "\n⌬ {}read set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == "leave":
                        ret = "Now set : " + str(lvin["textnya"])
                        ret += "\n\n⌬ {}leave on/off".format(setKey)
                        ret += "\n⌬ {}leave set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == "welcome":
                        ret = "Now set : " + str(wmin["textnya"])
                        ret += "\n\n⌬ {}welcome on/off".format(setKey)
                        ret += "\n⌬ {}welcome set <text>".format(setKey)
                        sendFooter(to, str(ret))
                    elif cmd == ".":
                        if msg._from in myAdmin:
                            if msg.toType == 2:
                                group = noobcoder.getGroup(to)
                                if group.invitee is None or group.invitee == []:
                                    noobcoder.sendMessage(msg.to, "No invites Pending")
                                else:
                                    invitee = [contact.mid for contact in group.invitee]
                                    for inv in invitee:
                                        noobcoder.cancelGroupInvitation(to, [inv])
                                        noobcoder.findAndAddContactsByMid(inv)                                        
                                        noobcoder.inviteIntoGroup(to, [inv])
#==========================================
                    elif cmd.startswith("read set "):
                        text_ = removeCmd("read set", text)
                        try:
                            tailah["siderPesan"] = text_
                            sendFooter(to,"「 Get Reader 」\nChanged to : " + text_)
                        except:
                            foto(to,"「Get Reader 」\nFailed to replace message")
                    elif cmd.startswith("leave set "):
                        text_ = removeCmd("leave set", text)
                        try:
                            lvin["textnya"] = text_
                            sendFooter(to,"「 LeaveMsg 」\nChanged to : " + text_)
                        except:
                            sendFooter(to,"「 LeaveMsg 」\nFailed to replace message")
                    elif cmd.startswith("welcome set "):
                        text_ = removeCmd("welcome set", text)
                        try:
                            wmin["textnya"] = text_
                            sendFooter(to,"「 WelcomeMsg 」\nChanged to : " + text_)
                        except:
                            sendFooter(to,"「 WelcomeMsg 」\nFailed to replace message")
                    elif cmd.startswith("bye "):
                        if msg._from in myAdmin:
                            number = removeCmd("bye", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    noobcoder.leaveGroup(G.id)
                                except:
                                    noobcoder.leaveGroup(G.id)
                                noobcoder.sendMessage(to, "「Leave 」\n\nGroup : " + G.name)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                    elif cmd == "support":
                        support(to)
                    elif cmd == "login" and msg._from not in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            try:
                                 def frzky():
                                     a = powpow()
                                     a.update({'x-lpqs' : '/api/v4/TalkService.do'})
                                     transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4/TalkService.do')
                                     transport.setCustomHeaders(a)
                                     protocol = TCompactProtocol.TCompactProtocol(transport)
                                     client = LineService.Client(protocol)
                                     qr = client.getAuthQrcode(keepLoggedIn=1, systemName='noobcoderBot-PC')
                                     link = "line://au/q/" + qr.verifier
                    #              noobcoder.sendMention(to, 'Click link @!, only 2 minutes\n{}'.format(link),"",[msg._from])
                                     contact = noobcoder.getContact(sender)
                                     LINKFOTO = "https://os.line.naver.jp/os/p/" + sender
                                     data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello , {}".format(user),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "CLICK HERE FOR LOGIN",
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                            "action": {
                                "type": "uri",
                                "uri": "{}".format(link)
                            }
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                                     sendTemplate(to, data)
                                     a.update({"x-lpqs" : '/api/v4/TalkService.do', 'X-Line-Access': qr.verifier})
                                     json.loads(requests.session().get('https://gd2.line.naver.jp/Q', headers=a).text)
                                     a.update({'x-lpqs' : '/api/v4p/rs'})
                                     transport = THttpClient.THttpClient('https://gd2.line.naver.jp/api/v4p/rs')
                                     transport.setCustomHeaders(a)
                                     protocol = TCompactProtocol.TCompactProtocol(transport)
                                     client = LineService.Client(protocol)
                                     req = LoginRequest()
                                     req.type = 1
                                     req.verifier = qr.verifier
                                     req.e2eeVersion = 1
                                     res = client.loginZ(req)
                                     if msg._from not in premium['listLogin']:
                                         premium['listLogin'][msg._from] =  '%s' % user
                                         isi = "{}".format(res.authToken)
                                         os.system('cp -r login {}'.format(user))
                                         os.system('cd {} && echo -n "{}" > token1.txt'.format(user, isi))
                                         os.system('screen -dmS {}'.format(user))
                                         os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                                         data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "File : {}".format(user),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "SUCESS TO LOGIN",
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                                         sendTemplate(to, data)
                                     else:
                                         noobcoder.sendMention(msg.to, '「 Req Login 」\n• Status : Failed\n• User: @!',' ', [msg._from])
                                 thread = threading.Thread(target=frzky)
                                 thread.daemon = True
                                 thread.start()
                            except:
                                 noobcoder.sendMention(msg.to, '「 Reg Login 」\n• Status : Failed\n •User: @!',' ', [msg._from])
                    elif cmd == "help":
                        try:
                            help = "Rname : {}".format(setKey)
                            help += "\nSname : Khie"
                            help += "\n\nGeneral Commands :\n"
                            help += "\n⌬ {}reader".format(setKey)
                            help += "\n⌬ {}mentions".format(setKey)
                            help += "\n\nService Commands :\n"
                            help += "\n⌬ {}login".format(setKey)
                            help += "\n⌬ {}logout".format(setKey)
                            help += "\n⌬ {}restart".format(setKey)
                            help += "\n\nOwner Commands :\n"
                            help += "\n⌬ {}addservice".format(setKey)
                            help += "\n⌬ {}delservice".format(setKey)
                            help += "\n⌬ {}list service".format(setKey)
                            help += "\n\nAuthor : @!                  "
                            mentions(to, str(help),[khietag])
                        except Exception as error:
                            sendFooter(to, "「 Result Error 」\n" + str(error))
#==========================================
                    elif cmd == "login":
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(msg.to, '⌬ User : @!\n⌬ Type : {}logout'.format(setKey),' ', [msg._from])
                    elif cmd == "logout" and msg._from in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            del premium['listLogin'][msg._from]
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('rm -rf {}'.format(str(user)))
                            time.sleep(2)
                            noobcoder.sendMention(msg.to, '⌬ User: @!\n⌬ Stats : Success to logout',' ', [msg._from])
                    elif cmd == "logout" and msg._from not in premium['listLogin']:
                        if msg._from in premium["myService"]:
                            noobcoder.sendMention(msg.to, '⌬ User : @!\n⌬ Type : {}login'.format(setKey),' ', [msg._from])
                    elif text.lower().startswith("addme "):
                        if msg._from not in premium['myService']:
                            nama = str(text.split(' ')[1])
                            premium['myService'][msg._from] =  '%s' % nama
                            noobcoder.sendMention(msg.to, "「 Add Me 」 \nAdd @! to Login..","",[msg._from])
                        else:
                            noobcoder.sendMention(msg.to, "「Add Me 」\nOwner @! already in List..","",[msg._from])
                    elif text.lower().startswith("addsb") and msg._from in myAdmin and to not in chatbot["botOff"]:
                        anu = msg.text.split(" ")
                        anu2 = msg.text.replace(anu[0] + " ","")
                        anu3 = anu2.split("|")
                        nama = str(anu3[0])
                        mid = str(anu3[1])
                        if mid not in premium['myService']:
                            premium['myService'][mid] =  '%s' % nama
                            noobcoder.sendMention(to, '「 Service 」\nAdd @!to service ','', [mid])
                        if mid in premium['myService']:
                            noobcoder.sendMention(to, '「 Service 」\nUser @!already in service  ','', [mid])
                    elif cmd.startswith("addservice ") and msg._from in myAdmin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 not in premium['myService']:
                                    nama = str(text.split(' ')[1])
                                    premium['myService'][key1] =  '%s' % nama
                                    noobcoder.sendMention(msg.to, '⌬ Added @! to service','', [key1])
                                else:
                                    noobcoder.sendMention(msg.to, '⌬ User @! already in service','', [key1])
                    elif cmd.startswith('delnumber ') and msg._from in myAdmin:
                        h = [a for a in premium['myService']]
                        mid = h[int(text.lower().split(' ')[1])-1]
                        user = premium["myService"][mid]
                        if mid in premium['myService'] and mid not in premium['listLogin']:
                            del premium['myService'][mid]
                            noobcoder.sendMention(to, ' Service Delete @!in service ','', [mid])
                        if mid in premium['listLogin']:
                            del premium['listLogin'][mid]
                            del premium['myService'][mid]
                            os.system("screen -S {} -X kill".format(user))
                            os.system('rm -r {}'.format(user))
                        noobcoder.sendMention(to, "User @!has been deleted.","",[mid])                        
                    elif cmd.startswith("delservice ") and msg._from in myAdmin:
                            if 'MENTION' in msg.contentMetadata.keys()!= None:
                                key = eval(msg.contentMetadata["MENTION"])
                                key1 = key["MENTIONEES"][0]["M"]
                                if key1 in premium['myService']:
                                    del premium['myService'][key1]
                                    noobcoder.sendMention(msg.to, '⌬ Deleted @! from service','', [key1])
                                else:
                                    noobcoder.sendMention(msg.to, '⌬ User @! not in service','', [key1])
                    elif text.lower().startswith("addsb") and msg._from in myAdmin and to not in chatbot["botOff"]:
                        anu = msg.text.split(" ")
                        anu2 = msg.text.replace(anu[0] + " ","")
                        anu3 = anu2.split("|")
                        nama = str(anu3[0])
                        mid = str(anu3[1])
                        if mid not in premium['myService']:
                            premium['myService'][mid] =  '%s' % nama
                            noobcoder.sendMention(to, '「 Service 」\nAdd @!to service ','', [mid])
                        if mid in premium['myService']:
                            noobcoder.sendMention(to, '「 Service 」\nUser @!already in service  ','', [mid])
                    elif cmd == "list service" and msg._from in myAdmin and to not in chatbot["botMute"]:
                        h = [a for a in premium['myService']]
                        k = len(h)//20
                        for aa in range(k+1):
                            if aa == 0:msgas = '「 List Service 」\n';no = aa
                            else:msgas = '「 List Service 」\n';no = aa * 20
                            for a in h[aa * 20 : (aa + 1) * 20]:
                                no+=1
                                if premium['myService'][a] == "":cd = "None."
                                else:cd = premium['myService'][a]
                                if no == len(h):msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                                else:msgas+='\n{}. @!\nFile : {}'.format(no,cd)
                            noobcoder.sendMention(msg.to, msgas,'', h[aa * 20 : (aa+1)*20])
                    elif cmd == "restart":
                        if msg._from in premium["myService"]:
                            user = premium["myService"][msg._from]
                            os.system("screen -S {} -X quit".format(str(user)))
                            os.system('screen -dmS {}'.format(user))
                            os.system('screen -r {} -X stuff "cd {} && python3 staff.py \n"'.format(user, user))
                            time.sleep(3)
                            noobcoder.sendMention(msg.to, '「  Restart Sb  」\n> @! Succes Restart selfbot',' ', [msg._from])
#==========================================
#==========================================
                    elif cmd.startswith("name "):
                        if msg._from in myAdmin:
                            string = removeCmd("name", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).displayName
                                profile = noobcoder.getProfile()
                                profile.displayName = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 Update Name 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                    elif cmd.startswith("status "):
                        if msg._from in myAdmin:
                            string = removeCmd("status", text)
                            if len(string) <= 10000000000:
                                pname = noobcoder.getContact(sender).statusMessage
                                profile = noobcoder.getProfile()
                                profile.statusMessage = string
                                noobcoder.updateProfile(profile)
                                noobcoder.sendMessage(to, "「 Update Status 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                    elif text.lower() == "req login":
                        contact = noobcoder.getContact(sender)
                        owner = "u6e882277271440a7c2e8a2a0a5c38cef"
                        noobcoder.sendContact(owner, "" + str(sender))
                        ayu = "Request Login :\nFrom @!"
                        mid = noobcoder.getContact(sender)
                        mentions(owner, ayu, [sender])
                        noobcoder.sendMessage(owner, "" + str(sender))
                        noobcoder.sendMention(to, "Hi @!\nThe request to enter the selfbots has been sent , please wait for the owner to accept your request","",[msg._from])
                    elif cmd.startswith("chatmaker "):
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        contact = noobcoder.getContact(sender)
                        owner = "u6e882277271440a7c2e8a2a0a5c38cef"
                        ayu = "Sender: @!"
                        ayu += "\nMessage: {}".format(txt)
                        mentions(owner, ayu, [sender])
                        noobcoder.sendMessage(owner, "" + str(sender))
                        noobcoder.sendMention(to, "Hi @!\nmessage has been send","",[msg._from])
                    elif cmd.startswith("pc "):
                        if msg._from in myAdmin:
                            user = removeCmd("pc", text)
                            noobcoder.sendMessage(user,"hello, the login request to the selfbot has been approved by the owner, now you can access the selfbot\n\nWanna try to login ?\n\nType : Login")
#==========================================
                    elif cmd == "ping":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "PONG ! @!","",[msg._from])
                    elif cmd == "reboot":
                        if msg._from in myAdmin:
                            noobcoder.sendMention(to, "@! Brb , going to pee",' ', [msg._from])
                            restartBot()
                        else:pass
                    elif cmd == "lol":
                        true = True
                        data={"type":"flex","altText":"Eric Bots","contents":{
        "contents": [
            {
                "body": {
                    "contents": [
                        {
                            "aspectMode": "cover",
                            "aspectRatio": "10:4.5",
                            "gravity": "top",
                            "offsetTop": "0px",
                            "size": "full",
                            "type": "image",
                            "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "4:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.gifer.com/NTlz.gif"
                                }
                            ],
                            "cornerRadius": "15px",
                            "layout": "horizontal",
                            "offsetBottom": "3px",
                            "offsetEnd": "4px",
                            "offsetStart": "4px",
                            "offsetTop": "3px",
                            "position": "absolute",
                            "type": "box"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "40px",
                            "offsetTop": "36px",
                            "position": "absolute",
                            "type": "box",
                            "width": "200px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "2px",
                            "height": "3px",
                            "layout": "vertical",
                            "offsetStart": "3px",
                            "offsetTop": "79px",
                            "position": "absolute",
                            "type": "box",
                            "width": "294px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "8px",
                            "height": "40px",
                            "layout": "vertical",
                            "offsetStart": "10px",
                            "offsetTop": "85px",
                            "position": "absolute",
                            "type": "box",
                            "width": "187px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/JC79rBH/87612-6bf98354-82d2-11e4-acf3-5cb72523fab8.jpg"
                                }
                            ],
                            "cornerRadius": "8px",
                            "height": "38px",
                            "layout": "vertical",
                            "offsetStart": "11px",
                            "offsetTop": "86px",
                            "position": "absolute",
                            "type": "box",
                            "width": "185px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://calls"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/8YfQVtr/20190427-185626.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "11px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/chat"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/ZHtFDts/20190427-185307.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "41px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "http://line.me/ti/p/~patih_adhi21"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/b53ztTR/20190427-191019.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "71px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "Https://smule.com/___AdHipatiH___"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/CntKh4x/20190525-152240.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "101px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/cameraRoll/multi"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/Wf8bQ2Z/20190625-105354.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "131px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "https://youtube.com"
                                    },
                                    "flex": 0,
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/XWQd8rj/20190625-201419.png"
                                }
                            ],
                            "height": "41px",
                            "layout": "vertical",
                            "offsetStart": "161px",
                            "offsetTop": "87px",
                            "position": "absolute",
                            "type": "box",
                            "width": "35px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "3px",
                            "layout": "vertical",
                            "offsetStart": "68px",
                            "offsetTop": "18px",
                            "position": "absolute",
                            "type": "box",
                            "width": "228px"
                        },
                        {
                            "backgroundColor": "#ccff00",
                            "contents": [
                                {
                                    "color": "#000000",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u23f010:21:39",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "16px",
                            "layout": "horizontal",
                            "offsetStart": "203px",
                            "offsetTop": "88px",
                            "position": "absolute",
                            "type": "box",
                            "width": "75px"
                        },
                        {
                            "backgroundColor": "#ccff00",
                            "contents": [
                                {
                                    "color": "#000000",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\ud83d\uddd3\ufe0f2020-01-07",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "16px",
                            "layout": "vertical",
                            "offsetStart": "203px",
                            "offsetTop": "107px",
                            "position": "absolute",
                            "type": "box",
                            "width": "75px"
                        },
                        {
                            "contents": [
                                {
                                    "align": "center",
                                    "color": "#ccffff",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\ud83c\udd81\ud83c\udd74\ud83c\udd82\ud83c\udd7f\ud83c\udd7e\ud83c\udd7d\ud83c\udd83\ud83c\udd70\ud83c\udd76",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "vertical",
                            "offsetStart": "45px",
                            "offsetTop": "3px",
                            "position": "absolute",
                            "type": "box",
                            "width": "150px"
                        },
                        {
                            "contents": [
                                {
                                    "align": "center",
                                    "color": "#ccffff",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u2b50\u2b50\u2b50\u2b50\u2b50",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "vertical",
                            "offsetStart": "201px",
                            "offsetTop": "3px",
                            "position": "absolute",
                            "type": "box",
                            "width": "90px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyIpu0Umx_H38rk5T09JzGubcNB9qd_D7KzVbIK5z3HgH_P0oq"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "70px",
                            "layout": "vertical",
                            "offsetStart": "7px",
                            "offsetTop": "8px",
                            "position": "absolute",
                            "type": "box",
                            "width": "70px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/LNF3C7S/201803255ab79c043db8e.jpg"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "35px",
                            "layout": "vertical",
                            "offsetStart": "38px",
                            "offsetTop": "39px",
                            "position": "absolute",
                            "type": "box",
                            "width": "200px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/YRQnwQY/20191210-190324.gif"
                                }
                            ],
                            "cornerRadius": "5px",
                            "height": "33px",
                            "layout": "vertical",
                            "offsetStart": "37px",
                            "offsetTop": "40px",
                            "position": "absolute",
                            "type": "box",
                            "width": "200px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.ibb.co/YRQnwQY/20191210-190324.gif"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "63px",
                            "layout": "vertical",
                            "offsetStart": "10px",
                            "offsetTop": "11px",
                            "position": "absolute",
                            "type": "box",
                            "width": "63px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://obs-sg.line-apps.com/myhome/c/download.nhn?userid=u500218bb2f290d906bc4cb3fe4c9173a&oid=8bebf371326b80eb8157ac41711be95c"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "59px",
                            "layout": "vertical",
                            "offsetStart": "12px",
                            "offsetTop": "13px",
                            "position": "absolute",
                            "type": "box",
                            "width": "59px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:4",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://obs.line-scdn.net/0hpl-gIWXsL0MQHgc33HxQFCxbIS5nMCkLaHxhJDYeeCBuLT8WJHk1LTQZIiE4fDsXeyxldz0ed3Ft"
                                }
                            ],
                            "cornerRadius": "60px",
                            "height": "59px",
                            "layout": "vertical",
                            "offsetStart": "12px",
                            "offsetTop": "13px",
                            "position": "absolute",
                            "type": "box",
                            "width": "59px"
                        },
                        {
                            "contents": [
                                {
                                    "color": "#ccff00",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\ud83d\udebaLukesxyz",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "horizontal",
                            "offsetStart": "80px",
                            "offsetTop": "20px",
                            "position": "absolute",
                            "type": "box",
                            "width": "155px"
                        },
                        {
                            "contents": [
                                {
                                    "color": "#ccff00",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u1d04\u0280\u1d07\u1d00\u1d1b\u1d0f\u0280",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "15px",
                            "layout": "horizontal",
                            "offsetStart": "239px",
                            "offsetTop": "20px",
                            "position": "absolute",
                            "type": "box",
                            "width": "70px"
                        },
                        {
                            "contents": [
                                {
                                    "color": "#ffffff",
                                    "offsetTop": "0px",
                                    "size": "xxs",
                                    "text": "\u029f\u1d00\u0262\u026a s\u026a\u0299\u1d1c\u1d0b \u0274\u1d0f \u1d1b\u1d00\u0262,...\u1d18\u1d0d \u1d00\u1d0a\u1d00 \u1d0a\u026a\u0262\u1d00 \u1d18\u1d07\u0274\u1d1b\u026a\u0274\u0262",
                                    "type": "text",
                                    "weight": "bold",
                                    "wrap": true
                                }
                            ],
                            "height": "30px",
                            "layout": "horizontal",
                            "offsetStart": "80px",
                            "offsetTop": "40px",
                            "position": "absolute",
                            "type": "box",
                            "width": "150px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyJMHWrZewTJL4WHMo6poUqX2h5Q4q9bG5e8n1XPzjAb_N4nZM"
                                }
                            ],
                            "cornerRadius": "3px",
                            "height": "38px",
                            "layout": "vertical",
                            "offsetStart": "242px",
                            "offsetTop": "38px",
                            "position": "absolute",
                            "type": "box",
                            "width": "38px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://obs-sg.line-apps.com/myhome/c/download.nhn?userid=u500218bb2f290d906bc4cb3fe4c9173a&oid=8bebf371326b80eb8157ac41711be95c"
                                }
                            ],
                            "cornerRadius": "3px",
                            "height": "36px",
                            "layout": "vertical",
                            "offsetStart": "243px",
                            "offsetTop": "39px",
                            "position": "absolute",
                            "type": "box",
                            "width": "36px"
                        },
                        {
                            "contents": [
                                {
                                    "action": {
                                        "type": "uri",
                                        "uri": "line://nv/profilePopup/mid=u4f3a9ed342c6baff4123b6b931406af4"
                                    },
                                    "aspectMode": "cover",
                                    "aspectRatio": "3:5",
                                    "gravity": "top",
                                    "offsetTop": "0px",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://i.imgur.com/o6hzpkS.jpg"
                                }
                            ],
                            "cornerRadius": "3px",
                            "height": "34px",
                            "layout": "vertical",
                            "offsetStart": "243px",
                            "offsetTop": "39px",
                            "position": "absolute",
                            "type": "box",
                            "width": "36px"
                        }
                    ],
                    "layout": "horizontal",
                    "paddingAll": "0px",
                    "type": "box"
                },
                "type": "bubble"
            }
        ],
        "type": "carousel"
    },
    "type": "flex"
}
                        sendTemplate(to,data)
                    elif cmd == "woy":
                        data={"type":"flex","altText":"Eric Bots","contents":{
        "contents": [
            {
                "body": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~@amv8806n"
                            },
                            "aspectMode": "cover",
                            "aspectRatio": "6.50:1",
                            "size": "xl",
                            "type": "image",
                            "url": "https://imagizer.imageshack.com/img922/7452/Our8Zd.png"
                        },
                        {
                            "contents": [
                                {
                                    "aspectMode": "fit",
                                    "aspectRatio": "1:1",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/u96b6bf957c5a028732e5397eb55d1256"
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xs",
                                    "text": "\n1. About\n2. Related\n3. Profile",
                                    "type": "text",
                                    "wrap": True
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xs",
                                    "text": "\n4. Media\n5. Prank\n6. Chitchat",
                                    "type": "text",
                                    "wrap": True
                                }
                            ],
                            "layout": "horizontal",
                            "spacing": "xl",
                            "type": "box"
                        }
                    ],
                    "layout": "vertical",
                    "spacing": "lg",
                    "type": "box"
                },
                "footer": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~1bay.gomez"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OWNER",
                            "type": "text"
                        },
                        {
                            "color": "#ffffff",
                            "margin": "xl",
                            "type": "separator"
                        },
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~@amv8806n"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OFFICIAL",
                            "type": "text"
                        }
                    ],
                    "layout": "horizontal",
                    "spacing": "sm",
                    "type": "box"
                },
                "styles": {
                    "body": {
                        "backgroundColor": "#000000"
                    },
                    "footer": {
                        "backgroundColor": "#800000"
                    }
                },
                "type": "bubble"
            },
            {
                "body": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~@amv8806n"
                            },
                            "aspectMode": "cover",
                            "aspectRatio": "6.50:1",
                            "size": "xl",
                            "type": "image",
                            "url": "https://imagizer.imageshack.com/img922/7452/Our8Zd.png"
                        },
                        {
                            "contents": [
                                {
                                    "aspectMode": "fit",
                                    "aspectRatio": "1:1",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/u96b6bf957c5a028732e5397eb55d1256"
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "\n1. Buat pap\n2. Ganti pap\n3. Keylist",
                                    "type": "text",
                                    "wrap": True
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "\n4. Addkey\n5. Contactlist\n6. Addcontact",
                                    "type": "text",
                                    "wrap": True
                                }
                            ],
                            "layout": "horizontal",
                            "spacing": "xl",
                            "type": "box"
                        }
                    ],
                    "layout": "vertical",
                    "spacing": "lg",
                    "type": "box"
                },
                "footer": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~1bay.gomez"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OWNER",
                            "type": "text"
                        },
                        {
                            "color": "#ffffff",
                            "margin": "xl",
                            "type": "separator"
                        },
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~@amv8806n"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OFFICIAL",
                            "type": "text"
                        }
                    ],
                    "layout": "horizontal",
                    "spacing": "sm",
                    "type": "box"
                },
                "styles": {
                    "body": {
                        "backgroundColor": "#000000"
                    },
                    "footer": {
                        "backgroundColor": "#800000"
                    }
                },
                "type": "bubble"
            },
            {
                "body": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~@amv8806n"
                            },
                            "aspectMode": "cover",
                            "aspectRatio": "6.50:1",
                            "size": "xl",
                            "type": "image",
                            "url": "https://imagizer.imageshack.com/img922/7452/Our8Zd.png"
                        },
                        {
                            "contents": [
                                {
                                    "aspectMode": "fit",
                                    "aspectRatio": "1:1",
                                    "size": "full",
                                    "type": "image",
                                    "url": "https://os.line.naver.jp/os/p/u96b6bf957c5a028732e5397eb55d1256"
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "1. Settings\n2. Welcoming\n3. Share on\n4. Share off\n5. Chatbot on",
                                    "type": "text",
                                    "wrap": True
                                },
                                {
                                    "color": "#ffffff",
                                    "size": "xxs",
                                    "text": "6. Chatbot off\n7. Tracking on\n8. Tracking off\n9. Antiunsend on\\off",
                                    "type": "text",
                                    "wrap": True
                                }
                            ],
                            "layout": "horizontal",
                            "spacing": "xl",
                            "type": "box"
                        }
                    ],
                    "layout": "vertical",
                    "spacing": "lg",
                    "type": "box"
                },
                "footer": {
                    "contents": [
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~1bay.gomez"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OWNER",
                            "type": "text"
                        },
                        {
                            "color": "#ffffff",
                            "margin": "xl",
                            "type": "separator"
                        },
                        {
                            "action": {
                                "type": "uri",
                                "uri": "line://ti/p/~@amv8806n"
                            },
                            "align": "center",
                            "color": "#ffffff",
                            "size": "xxs",
                            "text": "OFFICIAL",
                            "type": "text"
                        }
                    ],
                    "layout": "horizontal",
                    "spacing": "sm",
                    "type": "box"
                },
                "styles": {
                    "body": {
                        "backgroundColor": "#000000"
                    },
                    "footer": {
                        "backgroundColor": "#800000"
                    }
                },
                "type": "bubble"
            }
        ],
        "type": "carousel"
    },
    "type": "flex"
}
                        sendTemplate(to,data)
#==========================================
                    elif cmd == "join on":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == True:
                                msgs=" 「 Join 」\nJoin already Enable♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to Enable♪"
                                settings["autoJoin"] = True
                            sendFooter(to, msgs)
                    elif cmd == "join off":
                        if msg._from in myAdmin:
                            if settings["autoJoin"] == False:
                                msgs=" 「 Join 」\nJoin already DISABLED♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to DISABLED♪"
                                settings["autoJoin"] = False
                            sendFooter(to, msgs)
                    elif cmd.startswith("$"):
                        if msg._from in myAdmin:
                            kntl = removeCmd("$", text)
                            ikkeh = os.popen("{}".format(str(kntl)))
                            enaena = ikkeh.read()
                            noobcoder.sendMessage(to, "{}".format(str(enaena)))
                            ikkeh.close()
                    elif cmd == "screenlist":
                        if msg._from in myAdmin:
                            proses = os.popen("screen -list")
                            a = proses.read()
                            sendFooter1(to, "{}".format(str(a)))
                            proses.close()
                    elif cmd.startswith("post"):
                        if msg._from in myAdmin:
                            shar = text.split("-")
                            gs = noobcoder.getGroup(msg.to)
                            jmlh = int(shar[1])
                            sendFooter(to, "Waiting for share.")
                            if jmlh <= 1000:
                                for baba in range(jmlh):
                                    try:
                                        noobcoder.sendPostToTalk(to, str(shar[2]))
                                    except:
                                        pass
                                sendFooter(to, "Sucess")
                            else:
                                sendFooter(to, "Amount is wrong")
                    elif cmd.startswith("postall"):
                        if msg._from in myAdmin:
                            shar = text.split("-")
                            shareall(to, shar[1])
#==========================================
#==========================================
                    elif cmd == "mentions":
                        group = noobcoder.getGroup(to);nama = [contact.mid for contact in group.members];nama.remove(noobcoder.getProfile().mid)
                        noobcoder.datamention(to,'Mentions',nama)
#==========================================
#==========================================
                    elif cmd.startswith("cvp"):
                        if msg._from in myAdmin:
                            link = removeCmd("cvp", text)
                            contact = noobcoder.getContact(sender)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Download...")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                            pict = noobcoder.downloadFileURL(pic)
                            vids = "TeamAnuBot.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            noobcoder.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Succes")
                            os.remove("TeamAnuBot.mp4")                            
#==========================================
#==========================================
                    elif cmd == "debug":
                       if msg._from in myAdmin:
                            noobcoder.sendMessage(to, debug())
                    elif cmd == "speed":
                        start = time.time()
                        noobcoder.sendMessage("u2cf74acf6ed04d122def4db8ffdd2e39", '</>')
                        elapsed_time = time.time() - start
                        noobcoder.sendMessage(to,"Time:\n%s"%str(round(elapsed_time,5)))
#==========================================
#==========================================
                    elif cmd == "glist":
                       if msg._from in myAdmin:
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = noobcoder.getGroupIdsJoined()
                            sd = noobcoder.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n\n「 Command 」\n\n> Remote Mention\nUsage: #Glist [num] tag [1|<|>|-]\n\n> Remote Kick\nUsage: #glist [num] kick [1|<|>|-]\n\n> Leave Groups\nUsage: #Leave [num]\n\n> Get QR\nUsage: #Openqr  [num]\n\n> Cek Member\nUsage: #Glist [num]\nUsage: #Glist [num] mem [num]".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} | {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                noobcoder.generateReplyMessage(msg.id)
                                noobcoder.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                    elif cmd.startswith('glist'):
                        if msg._from in myAdmin:
                            to = msg.to
                            gid = noobcoder.getGroupIdsJoined()
                            group = noobcoder.getGroup(gid[int(cmd.split(' ')[1])-1])
                            nama = [a.mid for a in group.members]
                            if len(cmd.split(" ")) == 2:
                                total = "Local ID: {}".format(int(cmd.split(' ')[1]))
                                noobcoder.datamention(to,'List Member',nama,'\n├Group: '+group.name[:20]+'\n├'+total)
                            if len(cmd.split(" ")) == 4:
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' mem '):noobcoder.getinformation(to,nama[int(cmd.split(' ')[3])-1],wait)
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' tag'):noobcoder.adityaarchi(wait,'Mention','tag',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                                if cmd.startswith('glist '+cmd.split(' ')[1]+' kick'):noobcoder.adityaarchi(wait,'Kick Member','kick',gid[int(cmd.split(' ')[1])-1],cmd.split(' ')[3],msg,"\n├Group: {}\n├Local ID: {}".format(group.name[:20],int(cmd.split(' ')[1])),nama=nama)
                    if cmd.startswith("leave groups "):
                        if msg.toType in [0,1,2]:
                            gid = noobcoder.getGroupIdsJoined()
                            if len(cmd.split(" ")) == 3:
                                selection = MySplit(cmd.split(' ')[2],range(1,len(gid)+1))
                                k = len(gid)//100
                                for a in range(k+1):
                                    if a == 0:eto='╭「 Leave Group 」─'
                                    else:eto='├「 Leave Group 」─'
                                    text = ''
                                    no = 0
                                    for i in selection.parse()[a*100 : (a+1)*100]:
                                        noobcoder.leaveGroup(gid[i - 1])
                                        no+=1
                                        if no == len(selection.parse()):text+= "\n╰{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                        else:text+= "\n│{}. {}".format(i,noobcoder.getGroup(gid[i - 1]).name)
                                    noobcoder.sendMessage(to,eto+text)
                    elif cmd.startswith("gcast "):
                      if msg._from in myAdmin:
                            txt = removeCmd("gcast", text)
                            groups = noobcoder.getGroupIdsJoined()
                            for group in groups:
                                sendFooter(group, "「 Group Broadcast 」\n{}".format(str(txt)))
                                time.sleep(1)
                            sendFooter(to, "Succes broadcast to {} group".format(str(len(groups))))
                    elif cmd.startswith('joinme '):
                         if msg._from in myAdmin:
                             text = msg.text.split()
                             number = text[1]
                             if number.isdigit():
                              groups = noobcoder.getGroupIdsJoined()
                              if int(number) < len(groups) and int(number) >= 0:
                                  groupid = groups[int(number)]
                                  group = noobcoder.getGroup(groupid)
                                  target = sender
                                  try:
                                      noobcoder.getGroup(groupid)
                                      noobcoder.findAndAddContactsByMid(target)
                                      noobcoder.inviteIntoGroup(groupid, [target])
                                      noobcoder.sendMessage(msg.to,"Succes invite to " + str(group.name))
                                  except:
                                      noobcoder.sendMessage(msg.to,"I no there baby")

                    elif cmd.startswith('invme '):
                         if msg._from in myAdmin:
                             cond = cmd.split(" ")
                             num = int(cond[1])
                             gid = noobcoder.getGroupIdsJoined()
                             group = noobcoder.getCompactGroup(gid[num-1])
                             noobcoder.findAndAddContactsByMid(sender)
                             noobcoder.inviteIntoGroup(gid[num-1],[sender])

                    elif cmd.startswith("openqr "):
                      if msg._from in myAdmin:
                            number = removeCmd("openqr", text)
                            groups = noobcoder.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = noobcoder.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    noobcoder.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(noobcoder.reissueGroupTicket(G.id)))
                                sendFooter(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                noobcoder.sendMessage(to, str(error))
                    elif cmd == "/byeall":
                        if msg._from in myAdmin:
                            anu = noobcoder.getGroupIdsJoined()
                            for i in anu:
                                try:
                                    noobcoder.leaveGroup(i)
                                except Exception as e:
                                    noobcoder.sendMessage(msg.to, e)
                        else:noobcoder.sendMention(msg.to, "Lo siapa sih @!NGENTOT!!!","SIKONTOL",' ', [msg._from])
                    elif cmd == "hmm":
                        if msg._from in myAdmin:
                            helppss(to)
                    if text.lower() == "rname":
                        if msg._from in myAdmin:
                            key = settings["keyCommand"]
                            if settings["setKey"] == True:
                                statuskey = "Enabled"
                            else:
                                statuskey = "Disabled"
                            sendFooter(to, "⌬ Rname : "+str(key.title())+"\n⌬ Status : "+str(statuskey))
                    if text.lower() == "rname on":
                        if msg._from in myAdmin:
                            settings["setKey"] = True
                            sendFooter(to, "Rname has been enabled")
                    if text.lower() == "rname off":
                        if msg._from in myAdmin:
                            settings["setKey"] = False
                            sendFooter(to, "Rname has been disabled")
                    if text.lower().startswith("scoutflex "):
                        if msg._from in myAdmin:
                            mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                            mentionees = mention['MENTIONEES']
                            lists = [] 
                            for mention in mentionees:
                                if mention["M"] not in lists:
                                    lists.append(mention["M"])
                            if lists != []:
                              for x in lists:
                                appendSteals(x)
                              noobcoder.sendMessage(to, "Done.. Now u can waiting target send flex message!")
                    if text.lower() == "clearflex":
                        if msg._from in myAdmin:
                          clearSteals()
                          noobcoder.sendMessage(to, "Data steal flex message is cleared now & set to off.")
#==========================================
        if op.type == 55:
            if op.param1 in tailah["siderTemp"] and op.param2 not in tailah["siderTemp"][op.param1]:
                tailah["siderTemp"][op.param1].append(op.param2)
                if "@!" in settings["readerPesan"]:
                    contact = noobcoder.getContact(op.param2)
                    pesan = tailah["siderPesan"]
                    data={"type":"flex","altText":"Eric Bots","contents":{
  "type": "bubble",
  "body": {
    "type": "box",
    "layout": "vertical",
    "contents": [
      {
        "type": "box",
        "layout": "vertical",
        "contents": [
          {
                    "type": "box",
                    "layout": "horizontal",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "horizontal",
                        "contents": [
                          {
                            "type": "image",
                            "url": "https://obs.line-scdn.net/{}".format(contact.pictureStatus)
                          }
                        ],
                        "width": "60px",
                        "height": "60px",
                        "borderWidth": "2px",
                        "borderColor": "#ffffff",
                        "cornerRadius": "100px"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "text",
                            "text": "Hello , {}".format(contact.displayName),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True
                          },
                          {
                            "type": "text",
                            "text": "{}".format(pesan),
                            "weight": "bold",
                            "size": "md",
                            "color": "#ffffff",
                            "wrap": True,
                          }
                        ],
                        "margin": "lg"
                      }
                    ]
                  }
        ],
        "paddingAll": "13px",
        "backgroundColor": "#000000",
        "cornerRadius": "2px",
        "margin": "xl"
      }
    ],
    "paddingAll": "0px"
  }
}}
                    sendTemplate(op.param1,data)
                
            if op.param1 in read["readPoint"]:
                _name = noobcoder.getContact(op.param2).displayName
                tz = pytz.timezone("Asia/Jakarta")
                timeNow = datetime.now(tz=tz)
                timeHours = datetime.strftime(timeNow," (%H:%M)")
                read["readMember"][op.param1][op.param2] = str(_name) + str(timeHours)
#==========================================
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)
    
def run():
    while True:
        try:
            ops = noobcoderPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(noobcoderBot(op))
                   noobcoderPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)
            
if __name__ == "__main__":
    run()